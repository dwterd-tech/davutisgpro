
import React, { useEffect, useState } from 'react';
import { 
    getAllUsers, getUniqueWorkplaces, getUserAssignedUnits, 
    assignUserToUnit, removeUserFromUnit 
} from '../services/mockDataService';
import { User } from '../types';
import { 
    ShieldCheck, Landmark, Plus, Trash2, User as UserIcon, 
    Search, Loader2, AlertCircle, ChevronRight, Briefcase
} from 'lucide-react';
import { ROLE_LABELS } from '../constants';
import { useAuth } from '../context/AuthContext';

export const UnitAssignments: React.FC = () => {
    // Fixed: Added useAuth to get current user for audit logging
    const { currentUser } = useAuth();
    const [users, setUsers] = useState<User[]>([]);
    const [workplaces, setWorkplaces] = useState<string[]>([]);
    const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
    const [assignedUnits, setAssignedUnits] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);
    const [processing, setProcessing] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const loadInitial = async () => {
            const [allUsers, allWorkplaces] = await Promise.all([
                getAllUsers('ADMIN'),
                getUniqueWorkplaces()
            ]);
            // Sadece Uzman ve Hekimleri filtrele
            setUsers(allUsers.filter(u => u.role === 'SPECIALIST' || u.role === 'DOCTOR'));
            setWorkplaces(allWorkplaces);
            setLoading(false);
        };
        loadInitial();
    }, []);

    useEffect(() => {
        const loadAssigned = async () => {
            if (selectedUserId) {
                const units = await getUserAssignedUnits(selectedUserId);
                setAssignedUnits(units);
            } else {
                setAssignedUnits([]);
            }
        };
        loadAssigned();
    }, [selectedUserId]);

    const handleAssign = async (unitName: string) => {
        if (!selectedUserId || !currentUser) return;
        setProcessing(true);
        // Fixed: Passed currentUser as third argument to assignUserToUnit
        await assignUserToUnit(selectedUserId, unitName, currentUser);
        const units = await getUserAssignedUnits(selectedUserId);
        setAssignedUnits(units);
        setProcessing(false);
    };

    const handleRemove = async (unitName: string) => {
        if (!selectedUserId || !currentUser) return;
        setProcessing(true);
        // Fixed: Passed currentUser as third argument to removeUserFromUnit
        await removeUserFromUnit(selectedUserId, unitName, currentUser);
        const units = await getUserAssignedUnits(selectedUserId);
        setAssignedUnits(units);
        setProcessing(false);
    };

    const filteredUsers = users.filter(u => 
        u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        u.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const selectedUser = users.find(u => u.id === selectedUserId);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 text-brand-600">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-black animate-pulse">VERİLER HAZIRLANIYOR...</p>
        </div>
    );

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* User List Panel */}
            <div className="lg:col-span-1 space-y-4">
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 h-full">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-brand-100 rounded-lg text-brand-600"><UserIcon size={24}/></div>
                        <div>
                            <h2 className="text-xl font-black text-gray-800 uppercase tracking-tight">Yetkili Listesi</h2>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Uzmanlar ve Hekimler</p>
                        </div>
                    </div>

                    <div className="relative mb-6">
                        <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                        <input 
                            type="text" 
                            placeholder="Kullanıcı ara..." 
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                        {filteredUsers.map(u => (
                            <button
                                key={u.id}
                                onClick={() => setSelectedUserId(u.id)}
                                className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-center justify-between group
                                    ${selectedUserId === u.id ? 'border-brand-600 bg-brand-50 shadow-md' : 'border-gray-50 bg-gray-50/50 hover:bg-white hover:border-gray-200'}`}
                            >
                                <div className="flex items-center gap-3">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm
                                        ${selectedUserId === u.id ? 'bg-brand-600 text-white' : 'bg-white text-gray-400 border border-gray-100'}`}>
                                        {u.name.charAt(0)}
                                    </div>
                                    <div>
                                        <p className="font-black text-gray-800 text-sm uppercase">{u.name}</p>
                                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-tighter">{ROLE_LABELS[u.role]}</p>
                                    </div>
                                </div>
                                <ChevronRight className={`transition-transform ${selectedUserId === u.id ? 'translate-x-1 text-brand-600' : 'text-gray-200 group-hover:translate-x-1'}`} size={20} />
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Assignment Panel */}
            <div className="lg:col-span-2 space-y-6">
                {!selectedUserId ? (
                    <div className="bg-white p-20 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                        <ShieldCheck className="text-gray-200 mb-6" size={80} />
                        <h3 className="text-xl font-black text-gray-400 uppercase tracking-widest">Atama Yapmak İçin Kullanıcı Seçin</h3>
                        <p className="text-sm text-gray-300 font-bold mt-2">Seçilen kullanıcının sorumlu olacağı birimler burada listelenecektir.</p>
                    </div>
                ) : (
                    <div className="space-y-6 animate-in slide-in-from-right-8 duration-300">
                        {/* Selected User Summary */}
                        <div className="bg-brand-900 text-white p-8 rounded-3xl shadow-xl flex items-center gap-6 relative overflow-hidden">
                            <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-2xl"></div>
                            <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center text-3xl font-black border border-white/20">
                                {selectedUser?.name.charAt(0)}
                            </div>
                            <div>
                                <h3 className="text-2xl font-black uppercase tracking-tight">{selectedUser?.name}</h3>
                                <div className="flex items-center gap-4 mt-1">
                                    <span className="text-[11px] font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest">{ROLE_LABELS[selectedUser!.role]}</span>
                                    <span className={`text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${selectedUser?.isAccessEnabled ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                        {selectedUser?.isAccessEnabled ? 'Veri Erişimi Aktif' : 'Veri Erişimi Kapalı'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Units Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Assigned Units */}
                            <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                                <h4 className="font-black text-gray-800 text-sm mb-6 flex items-center gap-2 uppercase">
                                    <ShieldCheck className="text-green-600" size={18} />
                                    Atanmış Birimler ({assignedUnits.length})
                                </h4>
                                <div className="space-y-2">
                                    {assignedUnits.length === 0 ? (
                                        <p className="py-10 text-center text-xs text-gray-300 italic font-bold">Henüz bir birim atanmamış.</p>
                                    ) : assignedUnits.map(unit => (
                                        <div key={unit} className="flex items-center justify-between p-4 bg-green-50 border border-green-100 rounded-2xl group transition-all hover:bg-green-100">
                                            <div className="flex items-center gap-3">
                                                <Landmark className="text-green-600" size={16} />
                                                <span className="text-xs font-black text-green-800 uppercase tracking-tight">{unit}</span>
                                            </div>
                                            <button 
                                                onClick={() => handleRemove(unit)}
                                                disabled={processing}
                                                className="p-2 text-red-300 hover:text-red-600 hover:bg-white rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Available Units */}
                            <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                                <h4 className="font-black text-gray-800 text-sm mb-6 flex items-center gap-2 uppercase">
                                    <Plus className="text-brand-600" size={18} />
                                    Birim Ekle
                                </h4>
                                <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                                    {workplaces
                                        .filter(w => !assignedUnits.includes(w))
                                        .map(unit => (
                                            <button 
                                                key={unit}
                                                onClick={() => handleAssign(unit)}
                                                disabled={processing}
                                                className="w-full flex items-center justify-between p-4 bg-gray-50 border border-transparent hover:border-brand-200 hover:bg-white rounded-2xl group transition-all"
                                            >
                                                <div className="flex items-center gap-3">
                                                    <Briefcase className="text-gray-400 group-hover:text-brand-600 transition-colors" size={16} />
                                                    <span className="text-xs font-black text-gray-600 group-hover:text-brand-800 transition-colors uppercase tracking-tight">{unit}</span>
                                                </div>
                                                <Plus className="text-gray-300 group-hover:text-brand-600 transition-all group-hover:rotate-90" size={16} />
                                            </button>
                                        ))}
                                    {workplaces.filter(w => !assignedUnits.includes(w)).length === 0 && (
                                        <p className="py-10 text-center text-xs text-gray-300 italic font-bold">Tüm birimler atandı.</p>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Security Notice */}
                        <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 flex items-start gap-4">
                            <AlertCircle className="text-indigo-600 flex-shrink-0" size={24} />
                            <div className="text-sm text-indigo-800 leading-relaxed font-bold">
                                <p className="uppercase text-[11px] mb-1">Önemli Güvenlik Notu:</p>
                                Atanan her birim, bu kullanıcının ilgili personellerin TC Kimlik, Sağlık ve Eğitim verilerine tam erişim sağlamasına olanak tanır. 
                                Sorumluluk sahası dışındaki birimleri atamaktan kaçınınız.
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
