import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getEmployeeByTc } from '../services/mockDataService';
import { PersonnelDetail } from './PersonnelDetail';
import { Loader2 } from 'lucide-react';

// Wrapper component to find the employee ID for the current user and render detail
export const MyProfile: React.FC = () => {
    const { currentUser, role } = useAuth();
    const [loading, setLoading] = useState(true);
    const [employeeId, setEmployeeId] = useState<string | null>(null);

    useEffect(() => {
        const findMyRecord = async () => {
            if (currentUser && currentUser.tcNumber) {
                const emp = await getEmployeeByTc(currentUser.tcNumber);
                if (emp) {
                    setEmployeeId(emp.id);
                }
            }
            setLoading(false);
        };
        findMyRecord();
    }, [currentUser]);

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <Loader2 className="w-8 h-8 animate-spin mb-2" />
                <p>Profiliniz yükleniyor...</p>
            </div>
        );
    }

    if (!employeeId) {
        return (
            <div className="bg-white p-8 rounded-lg shadow text-center max-w-lg mx-auto mt-10">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Sicil Kartı Bulunamadı</h3>
                <p className="text-gray-600 mb-4">
                    Kullanıcı kaydınız ile eşleşen bir Personel Sicil Kartı bulunamadı. 
                </p>
                <div className="bg-yellow-50 p-4 rounded text-sm text-yellow-800 text-left">
                    <strong>Olası Sebepler:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                        <li>Kayıt olurken TC Kimlik numaranızı girmemiş olabilirsiniz.</li>
                        <li>Yönetici henüz personel kaydınızı oluşturmamış veya onaylamamış olabilir.</li>
                        <li>Sistemde bir veri uyuşmazlığı olabilir.</li>
                    </ul>
                </div>
                <p className="mt-6 text-sm text-gray-500">Lütfen sistem yöneticisi ile iletişime geçiniz.</p>
            </div>
        );
    }

    // Reuse the PersonnelDetail page but with specific logic handled internally (User can't edit unless authorized)
    // We need to 'fake' the params for the component since it reads from useParams normally
    // However, PersonnelDetail reads useParams(). To reuse it without changing it significantly,
    // we can either change PersonnelDetail to accept a prop OR rely on router redirection.
    // Given the structure, let's just make PersonnelDetail capable of accepting an ID via props optionally,
    // or simply redirect to the URL.
    
    // BUT: Role protection prevents accessing /personnel/:id directly in layout links, 
    // effectively hiding it from nav, but the route exists.
    // To make this cleaner, let's just render a modified version or redirect? 
    // If we redirect to /personnel/123, the Sidebar might show "Personnel List" active state or deny access if we block route.
    
    // Let's go with Route Render trick in App.tsx, but here we render a context provider or modify PersonnelDetail?
    // Easiest: Copy logic or make PersonnelDetail smarter.
    // Let's look at PersonnelDetail code again. It uses useParams.
    
    // Hack: We can't easily pass props to a routed component that relies on useParams without changes.
    // Let's just Redirect to the actual route /personnel/:id 
    // AND update App.tsx to allow /personnel/:id for PERSONNEL role IF it matches their ID.
    
    // Since this is a Mock/Demo, let's actually just modify PersonnelDetail to accept an optional prop `forcedId`.
    
    return <PersonnelDetail forcedId={employeeId} />;
};