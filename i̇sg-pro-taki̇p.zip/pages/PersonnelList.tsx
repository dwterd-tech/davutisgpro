
import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { getEmployeesWithStatus, exportToExcel, importFromExcelMock, createEmployee, deleteEmployee } from '../services/mockDataService';
import { Employee, HazardClass } from '../types';
import { HAZARD_COLORS, HAZARD_LABELS, EXCEL_HEADERS } from '../constants';
import { useAuth } from '../context/AuthContext';
import { Search, Upload, FileSpreadsheet, Loader2, Eye, UserPlus, X, Trash2, Landmark, CheckCircle2, AlertTriangle, AlertCircle, Lock, ShieldAlert, FilterX, Filter } from 'lucide-react';

type EmployeeWithStatus = Employee & { risk: 'RED' | 'YELLOW' | 'GREEN', trainingDue: string, healthDue: string };

export const PersonnelList: React.FC = () => {
  const { role, currentUser } = useAuth();
  const [employees, setEmployees] = useState<EmployeeWithStatus[]>([]);
  const [filtered, setFiltered] = useState<EmployeeWithStatus[]>([]);
  const [search, setSearch] = useState('');
  
  // Filtre State'leri
  const [statusFilter, setStatusFilter] = useState<'RED' | 'YELLOW' | 'GREEN' | ''>('');
  const [hazardFilter, setHazardFilter] = useState<HazardClass | ''>('');
  
  const [loading, setLoading] = useState(false);
  
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStatus, setImportStatus] = useState('');
  const [importResult, setImportResult] = useState<{personnel: number, records: number, skipped: number} | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newEmp, setNewEmp] = useState({ 
    fullName: '', 
    tcNumber: '', 
    registrationNumber: '', // Yeni alan
    birthDate: '', 
    jobTitle: '', 
    workplaceName: '', 
    phone: '', 
    hazardClass: 'TEHLIKELI' as HazardClass 
  });

  const loadData = async () => {
      setLoading(true);
      try {
          const data = await getEmployeesWithStatus(undefined, currentUser || undefined);
          setEmployees(data);
      } catch (err) {
          console.error("Veri yükleme hatası:", err);
      } finally {
          setLoading(false);
      }
  };

  useEffect(() => { loadData(); }, [role, currentUser]);

  // Çoklu Filtreleme Mantığı
  useEffect(() => {
    let result = [...employees];
    const lower = search.toLocaleLowerCase('tr-TR').trim();
    
    if (lower) {
        result = result.filter(e => 
          e.fullName.toLocaleLowerCase('tr-TR').includes(lower) || 
          e.tcNumber.includes(lower) || 
          e.registrationNumber.toLocaleLowerCase('tr-TR').includes(lower) || 
          e.workplaceName.toLocaleLowerCase('tr-TR').includes(lower) || 
          (e.jobTitle && e.jobTitle.toLocaleLowerCase('tr-TR').includes(lower))
        );
    }
    
    if (statusFilter) {
        result = result.filter(e => e.risk === statusFilter);
    }
    
    if (hazardFilter) {
        result = result.filter(e => e.hazardClass === hazardFilter);
    }
    
    setFiltered(result);
  }, [search, employees, statusFilter, hazardFilter]);

  const resetFilters = () => {
      setSearch('');
      setStatusFilter('');
      setHazardFilter('');
  };

  const handleDelete = async (emp: Employee) => {
      if (!currentUser) return;
      if (!window.confirm(`${emp.fullName} isimli personeli KALICI olarak silmek istediğinize emin misiniz?`)) return;
      await deleteEmployee(emp.id, { id: currentUser.id, name: currentUser.name, role: currentUser.role });
      await loadData();
  };

  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    
    try {
      setLoading(true);
      await createEmployee(newEmp, { id: currentUser.id, name: currentUser.name, role: currentUser.role });
      setShowAddModal(false);
      setNewEmp({ fullName: '', tcNumber: '', registrationNumber: '', birthDate: '', jobTitle: '', workplaceName: '', phone: '', hazardClass: 'TEHLIKELI' });
      await loadData();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
      const exportData = filtered.map(emp => ({
          [EXCEL_HEADERS[0]]: emp.fullName,
          [EXCEL_HEADERS[1]]: emp.tcNumber,
          [EXCEL_HEADERS[2]]: emp.birthDate || '---',
          [EXCEL_HEADERS[3]]: emp.jobTitle,
          [EXCEL_HEADERS[4]]: emp.workplaceName,
          [EXCEL_HEADERS[5]]: emp.phone || '---',
          [EXCEL_HEADERS[6]]: HAZARD_LABELS[emp.hazardClass],
          [EXCEL_HEADERS[7]]: emp.trainingDue || 'Girilmemiş',
          [EXCEL_HEADERS[8]]: emp.healthDue || 'Girilmemiş',
          [EXCEL_HEADERS[9]]: emp.registrationNumber || '---', // Sicil No eklendi
          "RİSK DURUMU": emp.risk === 'RED' ? 'Süresi Dolmuş' : emp.risk === 'YELLOW' ? 'Süresi Yaklaşıyor' : 'Uygun'
      }));
      
      const dateStr = new Date().toLocaleDateString('tr-TR').replace(/\//g, '_').replace(/\./g, '_');
      exportToExcel(exportData, `ISG_Personel_Listesi_${dateStr}`);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]; 
      if (!file || !currentUser) return;

      setImporting(true);
      setImportProgress(10);
      setImportStatus('Dosya işleniyor...');

      const reader = new FileReader();
      reader.onload = async (event) => {
          const arrayBuffer = event.target?.result as ArrayBuffer;
          try {
              setImportProgress(50);
              setImportStatus('Veriler analiz ediliyor...');
              const result = await importFromExcelMock(arrayBuffer, { id: currentUser.id, name: currentUser.name, role: currentUser.role });
              setImportProgress(100);
              setImportStatus('Aktarım Tamamlandı!');
              setImportResult(result);
              setTimeout(async () => {
                  await loadData();
                  setImporting(false);
                  setImportResult(null);
              }, 2000);
          } catch(err: any) {
              alert("Hata: " + err.message);
              setImporting(false);
          }
      };
      reader.readAsArrayBuffer(file);
  };

  const canEdit = role === 'ADMIN' || role === 'OPERATOR';

  return (
    <div className="space-y-6 relative">
      {importing && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-brand-900/80 backdrop-blur-md p-4 animate-in fade-in duration-300">
              <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 text-center space-y-6 overflow-hidden relative border border-white/20">
                  <div className="absolute top-0 left-0 h-1.5 bg-brand-500 transition-all duration-500" style={{ width: `${importProgress}%` }}></div>
                  {importProgress < 100 ? <Loader2 size={64} className="mx-auto text-brand-600 animate-spin" /> : <CheckCircle2 size={64} className="mx-auto text-green-600 animate-bounce" />}
                  <div className="space-y-2">
                      <h3 className="text-2xl font-black text-gray-800">{importStatus}</h3>
                      {importResult && (
                          <div className="bg-green-50 p-4 rounded-xl text-left space-y-1">
                              <p className="text-sm text-green-800 font-bold">✓ {importResult.personnel} Personel Eklendi/Güncellendi</p>
                              <p className="text-sm text-green-800 font-bold">✓ {importResult.records} ISG Kaydı Eklendi</p>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* STICKY FILTER AREA */}
      <div className="sticky top-[-1px] z-20 bg-gray-100 pb-4 pt-1">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-200 space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="relative w-full md:w-1/2">
                    <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input 
                        type="text" 
                        placeholder="Ad, TC, Sicil No veya Birim ara..." 
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 transition-all font-bold text-sm bg-gray-50/30" 
                        value={search} 
                        onChange={(e) => setSearch(e.target.value)} 
                    />
                </div>
                <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end">
                    {canEdit && (
                        <>
                            <button onClick={() => setShowAddModal(true)} className="flex items-center space-x-2 bg-brand-700 text-white px-4 py-2.5 rounded-xl font-black shadow-lg shadow-brand-100 hover:bg-brand-800 transition-all transform active:scale-95 text-xs uppercase tracking-widest">
                                <UserPlus size={16}/> <span>Personel Ekle</span>
                            </button>
                            <input type="file" ref={fileInputRef} onChange={handleImport} className="hidden" accept=".csv" />
                            <button onClick={() => fileInputRef.current?.click()} className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all transform active:scale-95 text-xs uppercase tracking-widest">
                                <Upload size={16}/> <span>Toplu Yükle</span>
                            </button>
                        </>
                    )}
                    <button onClick={handleExport} className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2.5 rounded-xl font-black shadow-lg shadow-green-100 hover:bg-green-700 transition-all transform active:scale-95 text-xs uppercase tracking-widest">
                        <FileSpreadsheet size={16}/> <span>Excel</span>
                    </button>
                </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mr-2">
                    <Filter size={14} className="text-brand-500" /> Hızlı Filtrele:
                </div>
                
                <select 
                    className={`text-xs font-black p-2 rounded-xl border outline-none transition-all cursor-pointer
                        ${statusFilter === 'RED' ? 'bg-red-50 border-red-200 text-red-700' : 
                          statusFilter === 'YELLOW' ? 'bg-yellow-50 border-yellow-200 text-yellow-700' :
                          statusFilter === 'GREEN' ? 'bg-green-50 border-green-200 text-green-700' :
                          'bg-gray-50 border-gray-100 text-gray-600'}`}
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as any)}
                >
                    <option value="">TÜM RİSK DURUMLARI</option>
                    <option value="RED">KRİTİK (SÜRESİ DOLANLAR)</option>
                    <option value="YELLOW">RİSKLİ (AZ KALANLAR)</option>
                    <option value="GREEN">UYGUN (GÜNCEL)</option>
                </select>

                <select 
                    className={`text-xs font-black p-2 rounded-xl border outline-none transition-all cursor-pointer
                        ${hazardFilter ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-gray-50 border-gray-100 text-gray-600'}`}
                    value={hazardFilter}
                    onChange={(e) => setHazardFilter(e.target.value as HazardClass)}
                >
                    <option value="">TÜM TEHLİKE SINIFLARI</option>
                    <option value="AZ_TEHLIKELI">{HAZARD_LABELS['AZ_TEHLIKELI']}</option>
                    <option value="TEHLIKELI">{HAZARD_LABELS['TEHLIKELI']}</option>
                    <option value="COK_TEHLIKELI">{HAZARD_LABELS['COK_TEHLIKELI']}</option>
                </select>

                {(statusFilter || hazardFilter || search) && (
                    <button 
                        onClick={resetFilters}
                        className="flex items-center gap-1.5 px-3 py-2 text-[10px] font-black text-red-500 hover:bg-red-50 rounded-xl transition-all uppercase tracking-widest"
                    >
                        <FilterX size={14} /> Filtreleri Temizle
                    </button>
                )}
            </div>
          </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50 text-[11px] font-black text-gray-400 uppercase tracking-widest">
                  <tr><th className="px-6 py-5 text-left">Personel Bilgileri</th><th className="px-6 py-5 text-left">Birim / Daire</th><th className="px-6 py-5 text-left">Risk Durumu</th><th className="px-6 py-5 text-left">Tehlike Sınıfı</th><th className="px-6 py-5 text-right">Eylem</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                  {loading && !showAddModal ? (
                      <tr><td colSpan={5} className="text-center py-20 text-brand-600 font-bold"><Loader2 className="animate-spin inline mr-2" /> Veriler Yükleniyor...</td></tr>
                  ) : filtered.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="text-center py-32 space-y-4">
                            {(role === 'SPECIALIST' || role === 'DOCTOR') && !currentUser?.isAccessEnabled ? (
                                <div className="flex flex-col items-center max-w-sm mx-auto">
                                    <ShieldAlert size={48} className="text-red-400 mb-4 animate-pulse" />
                                    <p className="text-gray-800 font-black uppercase text-sm">ERİŞİM YETKİSİ BEKLENİYOR</p>
                                    <p className="text-xs text-gray-400 mt-2 font-bold leading-relaxed">
                                        Uzman/Hekim profiliniz henüz sistem yöneticisi tarafından onaylanmamıştır.
                                    </p>
                                </div>
                            ) : (
                                <>
                                    <AlertCircle size={40} className="mx-auto text-gray-200" />
                                    <p className="text-gray-400 font-black text-xs uppercase tracking-widest">Arama kriterlerine uygun personel bulunamadı.</p>
                                    <button onClick={resetFilters} className="text-brand-600 text-[10px] font-black uppercase underline">Tümünü Göster</button>
                                </>
                            )}
                        </td>
                      </tr>
                  ) : filtered.map((emp) => (
                  <tr key={emp.id} className={`transition-all border-l-4 ${emp.risk === 'RED' ? 'border-red-500 bg-red-50/20' : emp.risk === 'YELLOW' ? 'border-yellow-500 bg-yellow-50/20' : 'border-transparent hover:bg-gray-50/50'}`}>
                      <td className="px-6 py-5 flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shadow-sm ${emp.risk === 'RED' ? 'bg-red-100 text-red-700' : emp.risk === 'YELLOW' ? 'bg-yellow-100 text-yellow-700' : 'bg-brand-100 text-brand-700'}`}>{emp.fullName.charAt(0)}</div>
                          <div>
                            <div className="text-sm font-black text-gray-800 uppercase tracking-tight">{emp.fullName}</div>
                            <div className="text-[10px] text-gray-400 font-mono font-bold tracking-tighter">TC: {emp.tcNumber} • SİCİL: {emp.registrationNumber}</div>
                          </div>
                      </td>
                      <td className="px-6 py-5 text-xs font-black text-gray-500 uppercase tracking-tight">{emp.workplaceName || '---'}</td>
                      <td className="px-6 py-5">
                         <span className={`text-[10px] font-black uppercase flex items-center gap-2 ${emp.risk === 'RED' ? 'text-red-700' : emp.risk === 'YELLOW' ? 'text-yellow-700' : 'text-green-700'}`}>
                             {emp.risk === 'RED' ? <AlertCircle size={16}/> : emp.risk === 'YELLOW' ? <AlertTriangle size={16}/> : <CheckCircle2 size={16}/>}
                             {emp.risk === 'RED' ? 'KRİTİK' : emp.risk === 'YELLOW' ? 'RİSKLİ' : 'UYGUN'}
                         </span>
                      </td>
                      <td className="px-6 py-5"><span className={`px-3 py-1.5 text-[9px] font-black rounded-lg border uppercase tracking-wider ${HAZARD_COLORS[emp.hazardClass]}`}>{HAZARD_LABELS[emp.hazardClass]}</span></td>
                      <td className="px-6 py-5 text-right flex justify-end gap-2">
                          {canEdit && <button onClick={() => handleDelete(emp)} className="p-2 text-gray-300 hover:text-red-600 transition-all" title="Sil"><Trash2 size={18}/></button>}
                          <Link to={`/personnel/${emp.id}`} className="bg-brand-600 text-white px-4 py-2 rounded-xl text-[10px] font-black hover:bg-brand-700 shadow-lg shadow-brand-100 transition-all flex items-center gap-2 uppercase tracking-widest"><Eye size={16}/> İncele</Link>
                      </td>
                  </tr>
                  ))}
              </tbody>
          </table>
        </div>
      </div>

      {/* ADD PERSONNEL MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-[150] bg-brand-900/60 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
              <div className="bg-brand-900 p-6 flex justify-between items-center text-white">
                  <div className="flex items-center gap-3">
                    <UserPlus size={24} />
                    <h3 className="text-xl font-black uppercase tracking-tight">Yeni Personel Kaydı</h3>
                  </div>
                  <button onClick={() => setShowAddModal(false)} className="text-white/60 hover:text-white transition-colors">
                    <X size={24} />
                  </button>
              </div>
              
              <form onSubmit={handleAddEmployee} className="p-8 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Ad Soyad</label>
                            <input 
                              required 
                              type="text" 
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.fullName}
                              onChange={(e) => setNewEmp({...newEmp, fullName: e.target.value})}
                              placeholder="Örn: Ahmet Yılmaz"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">TC Kimlik No</label>
                            <input 
                              required 
                              type="text" 
                              maxLength={11}
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.tcNumber}
                              onChange={(e) => setNewEmp({...newEmp, tcNumber: e.target.value})}
                              placeholder="11 Haneli TC"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Kurumsal Sicil No</label>
                            <input 
                              required 
                              type="text" 
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.registrationNumber}
                              onChange={(e) => setNewEmp({...newEmp, registrationNumber: e.target.value})}
                              placeholder="Örn: S-2024-001"
                            />
                          </div>
                      </div>
                      
                      <div className="space-y-4">
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Doğum Tarihi</label>
                            <input 
                              required 
                              type="date" 
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.birthDate}
                              onChange={(e) => setNewEmp({...newEmp, birthDate: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Birim / İş Yeri</label>
                            <input 
                              required 
                              type="text" 
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.workplaceName}
                              onChange={(e) => setNewEmp({...newEmp, workplaceName: e.target.value})}
                              placeholder="Örn: Merkez Atölye"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Görev / Unvan</label>
                            <input 
                              required 
                              type="text" 
                              className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                              value={newEmp.jobTitle}
                              onChange={(e) => setNewEmp({...newEmp, jobTitle: e.target.value})}
                              placeholder="Örn: Operatör"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Tehlike Sınıfı</label>
                                <select 
                                  className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm appearance-none"
                                  value={newEmp.hazardClass}
                                  onChange={(e) => setNewEmp({...newEmp, hazardClass: e.target.value as HazardClass})}
                                >
                                  <option value="AZ_TEHLIKELI">Az Tehlikeli</option>
                                  <option value="TEHLIKELI">Tehlikeli</option>
                                  <option value="COK_TEHLIKELI">Çok Tehlikeli</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Telefon</label>
                                <input 
                                  type="text" 
                                  className="w-full bg-gray-50 border border-gray-100 p-3 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm"
                                  value={newEmp.phone}
                                  onChange={(e) => setNewEmp({...newEmp, phone: e.target.value})}
                                  placeholder="05..."
                                />
                              </div>
                          </div>
                      </div>
                  </div>

                  <div className="pt-4 flex gap-4">
                      <button 
                        type="button" 
                        onClick={() => setShowAddModal(false)}
                        className="flex-1 py-4 text-xs font-black text-gray-400 hover:text-gray-600 transition-colors uppercase tracking-widest"
                      >
                        Vazgeç
                      </button>
                      <button 
                        type="submit" 
                        disabled={loading}
                        className="flex-[2] bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl text-xs font-black shadow-xl shadow-brand-100 transition-all transform active:scale-95 flex items-center justify-center gap-2 uppercase tracking-widest"
                      >
                        {loading ? <Loader2 className="animate-spin" size={18} /> : <UserPlus size={18} />}
                        Kaydı Tamamla
                      </button>
                  </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};
