
import React from 'react';
import { downloadExcelTemplate } from '../services/mockDataService';
import { Download, FileSpreadsheet, Info, CheckCircle2, AlertCircle, TableProperties } from 'lucide-react';
import { EXCEL_HEADERS } from '../constants';

export const Templates: React.FC = () => {
    return (
        <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                <div className="flex items-center space-x-4 mb-6">
                    <div className="p-3 bg-indigo-100 rounded-xl text-indigo-600 shadow-inner">
                        <FileSpreadsheet size={32} />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-gray-800 tracking-tight">Veri Transfer Merkezi</h2>
                        <p className="text-gray-500 font-medium">Toplu veri yükleme işlemleri için 10 sütunlu tam kapsamlı şablon.</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                        <h3 className="font-black text-xs uppercase tracking-widest flex items-center text-brand-600 mb-4">
                            <TableProperties className="w-4 h-4 mr-2" />
                            Kurumsal Şablon Sütun Sıralaması
                        </h3>
                        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 shadow-inner overflow-y-auto max-h-[450px]">
                            <ul className="space-y-3">
                                {EXCEL_HEADERS.map((header, idx) => (
                                    <li key={idx} className="flex items-center text-sm text-gray-700 font-bold group">
                                        <span className={`w-6 h-6 flex items-center justify-center rounded-lg text-[10px] font-black mr-3 shadow-sm border transition-all group-hover:scale-110
                                            ${header === 'SİCİL NO' ? 'bg-brand-600 text-white border-brand-700' : 'bg-white text-brand-600 border-brand-100'}`}>
                                            {idx + 1}
                                        </span>
                                        {header}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <div className="bg-brand-50/50 p-6 rounded-2xl border border-brand-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-5">
                                <Info size={120} />
                            </div>
                            <h4 className="font-black text-brand-800 mb-3 text-sm uppercase">Aktarım Kuralları</h4>
                            <ul className="text-xs text-brand-700 space-y-3 font-medium">
                                <li className="flex items-start">
                                    <CheckCircle2 className="w-4 h-4 mr-2 mt-0.5 text-brand-500 flex-shrink-0" />
                                    <b>Sicil No:</b> 10. sütun olarak mutlaka doldurulmalıdır. Sistem eşleştirmelerinde TC ile birlikte kullanılır.
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle2 className="w-4 h-4 mr-2 mt-0.5 text-brand-500 flex-shrink-0" />
                                    <b>Karakter Sorunu:</b> Ş, İ, Ğ gibi karakterlerin bozulmaması için UTF-8 kodlaması önerilir.
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle2 className="w-4 h-4 mr-2 mt-0.5 text-brand-500 flex-shrink-0" />
                                    <b>Tarih Formatı:</b> GG.AA.YYYY (Örn: 15.05.1985) şeklinde girilmelidir.
                                </li>
                                <li className="flex items-start">
                                    <CheckCircle2 className="w-4 h-4 mr-2 mt-0.5 text-brand-500 flex-shrink-0" />
                                    <b>Ayırıcı:</b> Excel'den kaydederken <b>"CSV (Virgülle Ayrılmış)"</b> seçeneğini kullanın.
                                </li>
                            </ul>
                        </div>

                        <div className="space-y-3">
                            <button 
                                onClick={downloadExcelTemplate}
                                className="w-full flex items-center justify-center space-x-3 bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl font-black shadow-xl shadow-brand-100 transition-all transform hover:-translate-y-1 active:scale-95"
                            >
                                <Download size={20} />
                                <span>10 Sütunlu Şablonu İndir (.CSV)</span>
                            </button>
                            <p className="text-[10px] text-center text-gray-400 font-bold uppercase tracking-tighter">
                                Windows ve Mac Excel ile tam uyumlu Türkçe Karakter Desteği
                            </p>
                        </div>
                    </div>
                </div>
                
                <div className="mt-10 pt-8 border-t border-gray-100">
                    <h3 className="font-black text-xs uppercase tracking-widest text-gray-400 mb-4">Örnek Veri Satırı Görünümü</h3>
                    <div className="overflow-x-auto rounded-xl border border-gray-100 shadow-sm">
                        <table className="min-w-full text-[10px] font-bold">
                            <thead className="bg-gray-50 text-gray-500 uppercase">
                                <tr>
                                    {EXCEL_HEADERS.map(h => <th key={h} className="px-3 py-2 text-left whitespace-nowrap">{h}</th>)}
                                </tr>
                            </thead>
                            <tbody className="bg-white text-gray-700">
                                <tr>
                                    <td className="px-3 py-2 whitespace-nowrap">Ahmet Örnek</td>
                                    <td className="px-3 py-2 whitespace-nowrap">12345678910</td>
                                    <td className="px-3 py-2 whitespace-nowrap">01.01.1990</td>
                                    <td className="px-3 py-2 whitespace-nowrap">Operatör</td>
                                    <td className="px-3 py-2 whitespace-nowrap">Merkez Atölye</td>
                                    <td className="px-3 py-2 whitespace-nowrap">05554443322</td>
                                    <td className="px-3 py-2 whitespace-nowrap">Çok Tehlikeli</td>
                                    <td className="px-3 py-2 whitespace-nowrap">15.01.2024</td>
                                    <td className="px-3 py-2 whitespace-nowrap">10.01.2024</td>
                                    <td className="px-3 py-2 whitespace-nowrap text-brand-600">S-2024-001</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100 flex items-start space-x-4 shadow-sm">
                <AlertCircle className="text-amber-600 w-6 h-6 flex-shrink-0" />
                <div className="text-sm text-amber-800 font-medium">
                    <p className="font-black mb-1 text-xs uppercase tracking-wider">Hata Alıyorsanız:</p>
                    <p className="text-xs leading-relaxed">
                        Yeni eklenen <b>Sicil No</b> sütunu 10. sütundur. Eski şablonlarınızı bu sütuna göre güncellemeyi unutmayınız. 
                        Aksi takdirde verileriniz yanlış eşleşebilir.
                    </p>
                </div>
            </div>
        </div>
    );
};
