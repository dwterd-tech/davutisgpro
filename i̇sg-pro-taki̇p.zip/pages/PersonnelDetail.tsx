
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
    getEmployeeById, getRecords, deleteRecord, getAllUsers, 
    getEmployeeDocuments, uploadEmployeeDocument, deleteEmployeeDocument,
    parseTRDate
} from '../services/mockDataService';
import { Employee, ISGRecord, RecordTypeKey, User, EmployeeDocument, DocumentType } from '../types';
import { HAZARD_COLORS, HAZARD_LABELS, RECORD_CONFIGS, ROLE_LABELS } from '../constants';
import { RecordForm } from '../components/RecordForm';
import { useAuth } from '../context/AuthContext';
import { 
    Trash2, AlertTriangle, CheckCircle, Clock, Briefcase, 
    Landmark, Fingerprint, Activity, Phone, Cake, UserCheck, 
    ShieldQuestion, Mail, ShieldAlert, FileText, Upload, Download, Loader2, FileDown, Eye, X, Maximize2, AlertCircle, Lock, Image as ImageIcon, Camera, AlertOctagon, FileDigit, Copy, Check
} from 'lucide-react';

interface Props { forcedId?: string; }

export const PersonnelDetail: React.FC<Props> = ({ forcedId }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { role, currentUser } = useAuth();
  const effectiveId = forcedId || id;
  
  const [employee, setEmployee] = useState<Employee | undefined>(undefined);
  const [linkedUser, setLinkedUser] = useState<User | undefined>(undefined);
  const [records, setRecords] = useState<ISGRecord[]>([]);
  const [documents, setDocuments] = useState<EmployeeDocument[]>([]);
  
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);
  
  const [isMobile, setIsMobile] = useState(false);
  const [copied, setCopied] = useState<'TC' | 'REG' | null>(null);

  // Document Management State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [viewingDoc, setViewingDoc] = useState<EmployeeDocument | null>(null);
  const [docDescription, setDocDescription] = useState('');

  // Yetki Kontrolleri
  const canDownloadPdf = role === 'ADMIN' || role === 'SPECIALIST' || role === 'DOCTOR' || role === 'OPERATOR';
  const canDownloadImage = role === 'ADMIN';

  useEffect(() => {
    setIsMobile(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent));
  }, []);

  const loadData = async () => {
    setLoading(true);
    setAccessDenied(false);

    if (effectiveId) {
        const emp = await getEmployeeById(effectiveId, currentUser || undefined);
        
        if (!emp) {
            if (role === 'SPECIALIST' || role === 'DOCTOR') {
                if (!currentUser?.isAccessEnabled) setAccessDenied(true);
            }
            setEmployee(undefined);
        } else {
            setEmployee(emp);
            const [recs, docs] = await Promise.all([
                getRecords(emp.id, 'APPROVED'),
                getEmployeeDocuments(emp.id)
            ]);
            setRecords(recs);
            setDocuments(docs);
            
            const allUsers = await getAllUsers('ADMIN'); 
            const user = allUsers.find(u => u.tcNumber === emp.tcNumber);
            setLinkedUser(user);
        }
    }
    setLoading(false);
  };

  useEffect(() => { loadData(); }, [effectiveId, currentUser]);

  const handleCopy = (text: string, type: 'TC' | 'REG') => {
      navigator.clipboard.writeText(text);
      setCopied(type);
      setTimeout(() => setCopied(null), 2000);
  };

  const handleRecordDelete = async (recId: string) => {
      if (!currentUser || role !== 'ADMIN') return;
      if (!window.confirm("Bu kaydı kalıcı olarak silmek istiyor musunuz?")) return;
      await deleteRecord(recId, currentUser);
      await loadData();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: DocumentType) => {
      const file = e.target.files?.[0];
      if (!file || !currentUser || !employee) return;

      const isImage = file.type.startsWith('image/');
      const isPdf = file.type === 'application/pdf';

      if (type === 'UYGUNSUZLUK' && !isImage) {
          alert("Lütfen sadece resim dosyası seçiniz.");
          return;
      }
      if (type !== 'UYGUNSUZLUK' && !isPdf) {
          alert("Lütfen sadece PDF dosyası yükleyiniz.");
          return;
      }

      setIsUploading(true);
      const reader = new FileReader();
      reader.onload = async (event) => {
          const base64 = event.target?.result as string;
          try {
              await uploadEmployeeDocument({
                  employeeId: employee.id,
                  name: file.name,
                  type: type,
                  fileData: base64,
                  uploadedBy: currentUser.name,
                  description: type === 'UYGUNSUZLUK' ? (docDescription || 'Uygunsuzluk tespiti') : undefined
              }, currentUser);
              setDocDescription('');
              await loadData();
          } catch (err) {
              alert("Dosya yüklenirken hata oluştu.");
          } finally {
              setIsUploading(false);
              if (fileInputRef.current) fileInputRef.current.value = '';
              if (imageInputRef.current) imageInputRef.current.value = '';
          }
      };
      reader.readAsDataURL(file);
  };

  const handleDeleteDoc = async (docId: string) => {
      if (!currentUser) return;
      if (!window.confirm("Bu dosyayı kalıcı olarak silmek istediğinize emin misiniz?")) return;
      await deleteEmployeeDocument(docId, currentUser);
      await loadData();
  };

  const downloadDoc = (doc: EmployeeDocument) => {
      const link = document.createElement('a');
      link.href = doc.fileData;
      link.download = doc.name;
      link.click();
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 text-brand-600">
        <Activity className="animate-spin mb-4" size={48} />
        <p className="font-black animate-pulse uppercase tracking-widest text-sm">Sicil Kartı Hazırlanıyor...</p>
    </div>
  );

  if (accessDenied) return (
      <div className="p-20 text-center bg-white rounded-3xl border border-red-100 shadow-xl max-w-2xl mx-auto space-y-6">
          <div className="w-20 h-20 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto"><Lock size={40} /></div>
          <h2 className="text-2xl font-black text-gray-800 uppercase tracking-tight">ERİŞİM ENGELLENDİ</h2>
          <p className="text-gray-500 font-bold leading-relaxed">Profiliniz için veri erişim yetkisi aktif edilmemiştir. Lütfen yetki için Admin ile iletişime geçiniz.</p>
          <button onClick={() => navigate('/personnel')} className="px-8 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-2xl text-xs font-black transition-all">LİSTEYE GERİ DÖN</button>
      </div>
  );

  if (!employee) return (
    <div className="p-10 text-center bg-white rounded-2xl border-2 border-dashed border-gray-200">
        <ShieldAlert size={48} className="mx-auto text-gray-300 mb-4" />
        <p className="text-gray-400 font-bold">Personel kaydı bulunamadı.</p>
    </div>
  );

  const officialDocs = documents.filter(d => d.type !== 'UYGUNSUZLUK');
  const nonCompliances = documents.filter(d => d.type === 'UYGUNSUZLUK');

  const renderStatusCard = (typeKey: RecordTypeKey) => {
      const config = RECORD_CONFIGS[typeKey];
      
      const typeRecords = records
        .filter(r => r.type === typeKey)
        .sort((a, b) => {
            const dateA = parseTRDate(a.nextDueDate)?.getTime() || 0;
            const dateB = parseTRDate(b.nextDueDate)?.getTime() || 0;
            return dateB - dateA;
        });

      const latest = typeRecords[0];
      const canAdd = role === 'ADMIN' || role === config.authorizedRole;

      let statusColor = "bg-red-50 border-red-200 text-red-700";
      let icon = <AlertTriangle className="text-red-600 w-8 h-8" />;
      let statusText = "GEÇERLİ KAYIT YOK";
      let dateText = latest ? latest.nextDueDate : "HİÇ YAPILMAMIŞ";

      if (latest) {
          const nextDateObj = parseTRDate(latest.nextDueDate);
          if (nextDateObj) {
              const diffDays = Math.ceil((nextDateObj.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
              if (diffDays > 60) { 
                  statusColor = "bg-green-50 border-green-200 text-green-700"; 
                  icon = <CheckCircle className="text-green-600 w-8 h-8" />;
                  statusText = "DURUM: UYGUN";
              }
              else if (diffDays > 0) { 
                  statusColor = "bg-yellow-50 border-yellow-200 text-yellow-700"; 
                  icon = <Clock className="text-yellow-600 w-8 h-8" />;
                  statusText = "DURUM: YAKLAŞIYOR";
              } else {
                  statusText = "DURUM: SÜRESİ DOLMUŞ";
              }
          }
      }

      return (
          <div className={`p-6 rounded-2xl shadow-sm border-l-8 ${statusColor.split(' ')[0]} bg-white space-y-4 transition-all hover:shadow-md border-gray-100`}>
              <div className="flex justify-between items-start">
                  <div>
                      <h4 className="font-black text-gray-800 uppercase text-sm tracking-tight">{config.label}</h4>
                      <p className={`text-[10px] font-black mt-1 ${statusColor.split(' ')[2]}`}>{statusText}</p>
                  </div>
                  {icon}
              </div>
              <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                  <p className="text-[9px] text-gray-400 font-black uppercase mb-1">Geçerlilik Tarihi</p>
                  <p className="text-2xl font-mono font-black text-gray-800 tracking-tighter">{dateText}</p>
              </div>
              <div className="space-y-2">
                  {typeRecords.length > 0 && (
                      <div className="pt-2 border-t mt-2">
                          <p className="text-[9px] font-black text-gray-400 mb-2 uppercase tracking-widest">Kayıt Geçmişi</p>
                          <div className="max-h-24 overflow-y-auto space-y-1 pr-2 custom-scrollbar">
                              {typeRecords.map(r => (
                                  <div key={r.id} className="flex justify-between items-center text-[10px] p-1.5 bg-gray-50 rounded-lg hover:bg-white border border-transparent hover:border-gray-100 transition-all font-bold group">
                                      <span className="text-gray-600">{r.date} <span className="text-gray-300 mx-1">→</span> <span className="text-gray-800">{r.nextDueDate}</span></span>
                                      {role === 'ADMIN' && <button onClick={() => handleRecordDelete(r.id)} className="text-red-300 hover:text-red-600 p-1 opacity-0 group-hover:opacity-100 transition-all"><Trash2 size={12}/></button>}
                                  </div>
                              ))}
                          </div>
                      </div>
                  )}
                  {canAdd && employee.isActive && (
                    <button onClick={() => setShowForm(true)} className="w-full mt-2 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-[10px] font-black transition shadow-lg shadow-brand-100 uppercase tracking-widest flex items-center justify-center gap-2">
                        <Activity size={14}/> YENİ İŞLEM GİRİŞİ
                    </button>
                  )}
              </div>
          </div>
      );
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-20">
        {/* Profile Summary Header */}
        <div className={`bg-white rounded-3xl shadow-xl p-8 border-t-8 relative overflow-hidden ${employee.isActive ? 'border-brand-600' : 'border-gray-300 grayscale'}`}>
            <div className="relative flex flex-col md:flex-row justify-between items-start gap-8">
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                    <div className="w-24 h-24 bg-brand-900 text-white rounded-3xl flex items-center justify-center text-4xl font-black shadow-2xl transform rotate-3">
                        {employee.fullName.charAt(0)}
                    </div>
                    <div className="text-center sm:text-left space-y-2">
                        <h2 className="text-4xl font-black text-gray-800 tracking-tight leading-none mb-4">{employee.fullName}</h2>
                        
                        <div className="flex flex-wrap justify-center sm:justify-start items-center gap-3">
                             {/* TC KİMLİK ALANI */}
                             <div className="flex items-center gap-2 bg-gray-100 px-3 py-1.5 rounded-xl border border-gray-200 group">
                                <Fingerprint size={14} className="text-gray-400" />
                                <span className="text-xs font-mono font-black text-gray-600 uppercase tracking-tight">TC: {employee.tcNumber}</span>
                                <button onClick={() => handleCopy(employee.tcNumber, 'TC')} className="text-gray-400 hover:text-brand-600 transition-colors">
                                    {copied === 'TC' ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                                </button>
                             </div>

                             {/* SİCİL NO ALANI */}
                             <div className="flex items-center gap-2 bg-brand-50 px-3 py-1.5 rounded-xl border border-brand-100 group">
                                <FileDigit size={14} className="text-brand-400" />
                                <span className="text-xs font-mono font-black text-brand-700 uppercase tracking-tight">SİCİL: {employee.registrationNumber}</span>
                                <button onClick={() => handleCopy(employee.registrationNumber, 'REG')} className="text-brand-400 hover:text-brand-800 transition-colors">
                                    {copied === 'REG' ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                                </button>
                             </div>
                        </div>

                        <div className="flex flex-wrap justify-center sm:justify-start items-center gap-3 mt-4">
                             <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black border uppercase ${linkedUser ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-400 border-gray-200'}`}>
                                <UserCheck size={14} /> {linkedUser ? `${ROLE_LABELS[linkedUser.role]} (AKTİF)` : 'HESAP TANIMSIZ'}
                             </span>
                        </div>
                    </div>
                </div>
                <div className={`px-8 py-4 rounded-2xl border-2 text-center shadow-lg transform -rotate-2 ${HAZARD_COLORS[employee.hazardClass]}`}>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">Tehlike Grubu</p>
                    <p className="font-black text-xl leading-tight">{HAZARD_LABELS[employee.hazardClass]}</p>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-10 pt-8 border-t border-gray-100">
                <div className="p-4 bg-gray-50/50 rounded-2xl border border-gray-100"><p className="text-[9px] text-gray-400 font-black uppercase mb-1">Birim / Daire</p><p className="text-xs font-black text-gray-700">{employee.workplaceName}</p></div>
                <div className="p-4 bg-gray-50/50 rounded-2xl border border-gray-100"><p className="text-[9px] text-gray-400 font-black uppercase mb-1">Görev / Pozisyon</p><p className="text-xs font-black text-gray-700">{employee.jobTitle}</p></div>
                <div className="p-4 bg-gray-50/50 rounded-2xl border border-gray-100"><p className="text-[9px] text-gray-400 font-black uppercase mb-1">İletişim</p><p className="text-xs font-black text-gray-700">{employee.phone || 'Girilmemiş'}</p></div>
                <div className="p-4 bg-gray-50/50 rounded-2xl border border-gray-100"><p className="text-[9px] text-gray-400 font-black uppercase mb-1">Doğum Tarihi</p><p className="text-xs font-black text-gray-700">{employee.birthDate}</p></div>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-6">
                {renderStatusCard('ISG_TRAINING')}
                {renderStatusCard('HEALTH_CHECK')}
            </div>

            <div className="lg:col-span-2 space-y-6">
                {/* Official Documents Section */}
                <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                    <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl"><FileText size={24}/></div>
                            <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Doküman Arşivi (PDF)</h3>
                        </div>
                        {role !== 'PERSONNEL' && (
                            <button onClick={() => fileInputRef.current?.click()} className="p-2 bg-brand-600 text-white rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-100">
                                <Upload size={20}/>
                                <input type="file" ref={fileInputRef} onChange={(e) => handleFileUpload(e, 'SERTIFIKA')} className="hidden" accept=".pdf" />
                            </button>
                        )}
                    </div>
                    
                    <div className="space-y-2">
                        {officialDocs.length === 0 ? (
                            <div className="py-10 text-center border-2 border-dashed border-gray-100 rounded-2xl text-gray-300 text-xs font-black italic">HİÇ BELGE YÜKLENMEMİŞ</div>
                        ) : officialDocs.map(doc => (
                            <div key={doc.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-transparent hover:border-gray-200 transition-all group">
                                <div className="flex items-center gap-3 overflow-hidden">
                                    <FileDown className="text-indigo-400 flex-shrink-0" size={20}/>
                                    <div className="overflow-hidden">
                                        <p className="text-sm font-black text-gray-700 truncate" title={doc.name}>{doc.name}</p>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase">{doc.uploadDate.split('T')[0]} • {doc.uploadedBy}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1">
                                    <button onClick={() => setViewingDoc(doc)} className="p-2 text-brand-600 hover:bg-white rounded-xl transition-all" title="Görüntüle"><Eye size={18}/></button>
                                    {canDownloadPdf && (
                                        <button onClick={() => downloadDoc(doc)} className="p-2 text-indigo-600 hover:bg-white rounded-xl transition-all" title="İndir"><Download size={18}/></button>
                                    )}
                                    {role === 'ADMIN' && <button onClick={() => handleDeleteDoc(doc.id)} className="p-2 text-red-300 hover:text-red-600 transition-all opacity-0 group-hover:opacity-100" title="Sil"><Trash2 size={18}/></button>}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Non-Compliance Section */}
                <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                    <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-red-50 text-red-600 rounded-xl"><AlertOctagon size={24}/></div>
                            <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Uygunsuzluk Bildirimi (FOTO)</h3>
                        </div>
                        {role !== 'PERSONNEL' && (
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    placeholder="Kısa açıklama..." 
                                    className="px-4 py-2 bg-gray-50 border border-gray-100 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-red-500 w-48"
                                    value={docDescription}
                                    onChange={(e) => setDocDescription(e.target.value)}
                                />
                                <button onClick={() => imageInputRef.current?.click()} className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg shadow-red-100 hover:bg-red-700 transition-all">
                                    <Camera size={18}/> {isMobile ? 'ÇEK' : 'YÜKLE'}
                                    <input type="file" ref={imageInputRef} onChange={(e) => handleFileUpload(e, 'UYGUNSUZLUK')} className="hidden" accept="image/*" capture="environment" />
                                </button>
                            </div>
                        )}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {nonCompliances.length === 0 ? (
                            <div className="col-span-full py-10 text-center border-2 border-dashed border-gray-100 rounded-2xl text-gray-300 text-xs font-black italic uppercase">UYGUNSUZLUK TESPİTİ BULUNMUYOR</div>
                        ) : nonCompliances.map(doc => (
                            <div key={doc.id} className="relative group aspect-square bg-gray-100 rounded-2xl overflow-hidden border border-gray-100 shadow-sm cursor-pointer" onClick={() => setViewingDoc(doc)}>
                                <img src={doc.fileData} alt="Uygunsuzluk" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent p-3 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                                    <p className="text-[10px] text-white font-black uppercase leading-tight truncate">{doc.description}</p>
                                    <p className="text-[8px] text-gray-300 font-bold mt-1 uppercase">{doc.uploadDate.split('T')[0]}</p>
                                </div>
                                {role === 'ADMIN' && (
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); handleDeleteDoc(doc.id); }} 
                                        className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-all shadow-md"
                                    >
                                        <Trash2 size={14}/>
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>

        {/* Full Screen Preview Modal */}
        {viewingDoc && (
            <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="relative w-full max-w-5xl h-[90vh] bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col">
                    <div className="flex justify-between items-center p-4 border-b bg-gray-50">
                        <div className="flex items-center gap-3">
                            {viewingDoc.type === 'UYGUNSUZLUK' ? <ImageIcon className="text-red-600"/> : <FileText className="text-indigo-600"/>}
                            <div>
                                <h4 className="text-sm font-black text-gray-800 uppercase">{viewingDoc.name}</h4>
                                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{viewingDoc.type} • {viewingDoc.uploadedBy}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            {viewingDoc.type !== 'UYGUNSUZLUK' && canDownloadPdf && (
                                <button onClick={() => downloadDoc(viewingDoc)} className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg shadow-indigo-100 transition-all">
                                    <Download size={16}/> İNDİR (PDF)
                                </button>
                            )}
                            {viewingDoc.type === 'UYGUNSUZLUK' && canDownloadImage && (
                                <button onClick={() => downloadDoc(viewingDoc)} className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg shadow-brand-100 transition-all">
                                    <Download size={16}/> İNDİR (RESİM)
                                </button>
                            )}
                            <button onClick={() => setViewingDoc(null)} className="p-2 hover:bg-gray-200 rounded-full transition-colors"><X size={24}/></button>
                        </div>
                    </div>
                    <div className="flex-1 overflow-auto bg-gray-200 p-4 flex items-center justify-center">
                        {viewingDoc.fileData.includes('pdf') ? (
                            <iframe src={viewingDoc.fileData} className="w-full h-full rounded-xl shadow-lg bg-white" title="PDF Preview" />
                        ) : (
                            <img src={viewingDoc.fileData} className="max-w-full max-h-full object-contain rounded-xl shadow-xl" alt="Preview" />
                        )}
                    </div>
                    {viewingDoc.description && (
                        <div className="p-6 bg-red-50 border-t border-red-100">
                            <p className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-1">Açıklama / Tespit Notu:</p>
                            <p className="text-sm font-bold text-gray-700">{viewingDoc.description}</p>
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* Global Record Form Modal */}
        {showForm && (
          <div className="fixed inset-0 z-[100] bg-brand-900/60 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-lg">
              <RecordForm 
                employeeId={employee.id} 
                hazardClass={employee.hazardClass}
                onSuccess={() => { setShowForm(false); loadData(); }}
                onCancel={() => setShowForm(false)}
              />
            </div>
          </div>
        )}

        {/* Operation Loader */}
        {isUploading && (
            <div className="fixed inset-0 z-[300] bg-brand-900/40 backdrop-blur-sm flex items-center justify-center">
                <div className="bg-white p-8 rounded-3xl shadow-2xl text-center space-y-4">
                    <Loader2 size={48} className="text-brand-600 animate-spin mx-auto"/>
                    <p className="text-sm font-black text-gray-800 uppercase tracking-widest">Dosya İşleniyor...</p>
                </div>
            </div>
        )}
    </div>
  );
};
