
import React, { useEffect, useState } from 'react';
import { 
    getAllRecords, getEmployees, approveRecord, rejectRecord, 
    getPendingUsers, approveUser, rejectUser, getAllUsers, 
    updateUserPassword, updateUserRole, deleteUser, bulkApproveRecords, getAuditLogs,
    getUnitSettings, updateUnitRestriction, toggleUserAccess, deleteUnitSetting
} from '../services/mockDataService';
import { ISGRecord, User, AuditLog, UnitSetting, Role } from '../types';
import { 
    Check, X, Users, Shield, Calendar, Loader2, Edit3, Trash2, 
    Save, CheckCircle2, CheckCircle, Square, CheckSquare, ListFilter, 
    Search, Activity, Clock, User as UserIcon, ShieldAlert, Lock, Unlock, Eye, EyeOff, ToggleRight, ToggleLeft
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { RECORD_CONFIGS, ROLE_LABELS } from '../constants';

type Tab = 'RECORDS' | 'USERS' | 'MANAGEMENT' | 'UNITS' | 'LOGS';

export const Approvals: React.FC = () => {
    const { role, currentUser } = useAuth();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<Tab>('RECORDS');
    
    // Lists
    const [pendingRecords, setPendingRecords] = useState<(ISGRecord & { employeeName: string, employeeTc: string })[]>([]);
    const [pendingUsers, setPendingUsers] = useState<User[]>([]);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [unitSettings, setUnitSettings] = useState<UnitSetting[]>([]);
    const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
    const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([]);
    const [logSearch, setLogSearch] = useState('');
    
    // Selection State
    const [selectedRecordIds, setSelectedRecordIds] = useState<string[]>([]);
    
    // Progress UI
    const [processingId, setProcessingId] = useState<string | null>(null);
    const [isBulkApproving, setIsBulkApproving] = useState(false);
    const [bulkProgress, setBulkProgress] = useState(0);

    // Management State
    const [editingUserId, setEditingUserId] = useState<string | null>(null);
    const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});
    const [tempUserData, setTempUserData] = useState<Record<string, { password?: string, role?: Role }>>({});

    useEffect(() => {
        if (role !== 'ADMIN') { navigate('/'); return; }
        loadData();
    }, [role, navigate, activeTab]);

    const loadData = async () => {
        const [recs, emps, usersPending, usersAll, units, logs] = await Promise.all([
            getAllRecords(), getEmployees(true), getPendingUsers(), getAllUsers(role), getUnitSettings(), getAuditLogs()
        ]);
        const recordsToApprove = recs.filter(r => r.status === 'PENDING').map(rec => ({
            ...rec,
            employeeName: emps.find(e => e.id === rec.employeeId)?.fullName || 'Bilinmeyen',
            employeeTc: emps.find(e => e.id === rec.employeeId)?.tcNumber || '---'
        }));
        setPendingRecords(recordsToApprove);
        setPendingUsers(usersPending);
        setAllUsers(usersAll);
        setUnitSettings(units);
        setAuditLogs(logs);
        setFilteredLogs(logs);
        setSelectedRecordIds([]);
        setEditingUserId(null);
        setTempUserData({});
    };

    useEffect(() => {
        const term = logSearch.toLocaleLowerCase('tr-TR').trim();
        setFilteredLogs(auditLogs.filter(l => 
            l.userName.toLocaleLowerCase('tr-TR').includes(term) || 
            l.action.toLocaleLowerCase('tr-TR').includes(term) || 
            l.details.toLocaleLowerCase('tr-TR').includes(term)
        ));
    }, [logSearch, auditLogs]);

    const togglePasswordVisibility = (userId: string) => {
        setVisiblePasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
    };

    const handleTempDataChange = (userId: string, field: 'password' | 'role', value: string) => {
        setTempUserData(prev => ({
            ...prev,
            [userId]: { ...prev[userId], [field]: value }
        }));
    };

    const saveUserChanges = async (userId: string) => {
        const changes = tempUserData[userId];
        if (!changes || !currentUser) return;
        
        setProcessingId(userId);
        try {
            if (changes.password) {
                await updateUserPassword(userId, changes.password, { id: currentUser.id, name: currentUser.name });
            }
            if (changes.role) {
                await updateUserRole(userId, changes.role, { id: currentUser.id, name: currentUser.name });
            }
            await loadData();
        } catch (e: any) {
            alert(e.message);
        } finally {
            setProcessingId(null);
        }
    };

    const toggleUnitStatus = async (unitName: string, currentStatus: boolean) => {
        if (!currentUser) return;
        setProcessingId(unitName);
        await updateUnitRestriction(unitName, !currentStatus, { id: currentUser.id, name: currentUser.name });
        await loadData();
        setProcessingId(null);
    };

    const handleDeleteUnitSetting = async (unitName: string) => {
        if (!currentUser) return;
        if (!window.confirm(`${unitName} biriminin özel kısıtlama ayarlarını sıfırlamak (silmek) istediğinize emin misiniz?`)) return;
        setProcessingId(unitName);
        await deleteUnitSetting(unitName, { id: currentUser.id, name: currentUser.name });
        await loadData();
        setProcessingId(null);
    };

    const handleToggleAccess = async (userId: string, currentStatus: boolean) => {
        if (!currentUser) return;
        setProcessingId(userId);
        await toggleUserAccess(userId, !currentStatus, { id: currentUser.id, name: currentUser.name });
        await loadData();
        setProcessingId(null);
    };

    const toggleRecordSelection = (id: string) => {
        setSelectedRecordIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    const toggleSelectAll = () => {
        if (selectedRecordIds.length === pendingRecords.length && pendingRecords.length > 0) {
            setSelectedRecordIds([]);
        } else {
            setSelectedRecordIds(pendingRecords.map(r => r.id));
        }
    };

    const handleBulkApproveSelected = async () => {
        if (!currentUser || selectedRecordIds.length === 0) return;
        if (!window.confirm(`${selectedRecordIds.length} adet seçili kaydı toplu olarak onaylamak istiyor musunuz?`)) return;
        
        setIsBulkApproving(true);
        setBulkProgress(25);
        try {
            await new Promise(r => setTimeout(r, 600));
            setBulkProgress(75);
            await bulkApproveRecords(selectedRecordIds, { id: currentUser.id, name: currentUser.name, role: currentUser.role });
            setBulkProgress(100);
            await loadData();
            setTimeout(() => { setIsBulkApproving(false); setBulkProgress(0); }, 1500);
        } catch (e: any) {
            alert("Hata: " + e.message);
            setIsBulkApproving(false);
        }
    };

    const handleAction = async (id: string, actionFn: any, ...args: any) => {
        setProcessingId(id);
        try { await actionFn(id, ...args); await loadData(); } 
        catch (e: any) { alert(e.message); }
        finally { setProcessingId(null); }
    };

    const handleDeleteUser = async (id: string) => {
        if (id === currentUser?.id) return;
        if (window.confirm("Bu kullanıcıyı sistemden KALICI olarak silmek istediğinize emin misiniz?")) {
            await deleteUser(id, { id: currentUser!.id, name: currentUser!.name });
            loadData();
        }
    };

    return (
        <div className="space-y-6 relative">
            {isBulkApproving && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center bg-brand-900/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
                    <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xs p-8 text-center space-y-4 border border-white/20">
                        {bulkProgress < 100 ? <Loader2 size={48} className="mx-auto text-brand-600 animate-spin" /> : <CheckCircle2 size={48} className="mx-auto text-green-500 animate-bounce" />}
                        <h3 className="text-xl font-black">{bulkProgress < 100 ? 'Onaylanıyor...' : 'İşlem Başarılı!'}</h3>
                        <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden"><div className="h-full bg-green-500 transition-all duration-700 ease-out" style={{ width: `${bulkProgress}%` }}></div></div>
                    </div>
                </div>
            )}

            <div className="flex border-b border-gray-200 overflow-x-auto whitespace-nowrap scrollbar-hide">
                <button onClick={() => setActiveTab('RECORDS')} className={`pb-4 px-6 text-sm font-medium transition-colors relative ${activeTab === 'RECORDS' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>
                    <div className="flex items-center gap-2"><Calendar className="w-4 h-4"/> Bekleyen Tarihler {pendingRecords.length > 0 && <span className="bg-red-500 text-white px-2 rounded-full text-[10px] font-bold">{pendingRecords.length}</span>}</div>
                </button>
                <button onClick={() => setActiveTab('USERS')} className={`pb-4 px-6 text-sm font-medium transition-colors relative ${activeTab === 'USERS' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>
                    <div className="flex items-center gap-2"><Users className="w-4 h-4"/> Başvurular {pendingUsers.length > 0 && <span className="bg-blue-500 text-white px-2 rounded-full text-[10px] font-bold">{pendingUsers.length}</span>}</div>
                </button>
                <button onClick={() => setActiveTab('UNITS')} className={`pb-4 px-6 text-sm font-medium transition-colors relative ${activeTab === 'UNITS' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>
                    <div className="flex items-center gap-2"><ShieldAlert className="w-4 h-4"/> Birim Yetkileri</div>
                </button>
                <button onClick={() => setActiveTab('MANAGEMENT')} className={`pb-4 px-6 text-sm font-medium transition-colors relative ${activeTab === 'MANAGEMENT' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>
                    <div className="flex items-center gap-2"><Shield className="w-4 h-4"/> Kullanıcı Yönetimi</div>
                </button>
                <button onClick={() => setActiveTab('LOGS')} className={`pb-4 px-6 text-sm font-medium transition-colors relative ${activeTab === 'LOGS' ? 'text-brand-600 border-b-2 border-brand-600' : 'text-gray-500'}`}>
                    <div className="flex items-center gap-2"><Activity className="w-4 h-4"/> Sistem Logları</div>
                </button>
            </div>

            <div className="mt-6">
                {activeTab === 'RECORDS' && (
                    <div className="space-y-4">
                        {pendingRecords.length > 0 && (
                            <div className="flex flex-col sm:flex-row justify-between items-center bg-white p-5 rounded-2xl border border-gray-200 shadow-sm gap-4">
                                <button onClick={toggleSelectAll} className="flex items-center gap-3 text-sm font-black text-gray-600 hover:text-brand-600 transition-all transform active:scale-95">
                                    {selectedRecordIds.length === pendingRecords.length ? <CheckSquare size={22} className="text-brand-600" /> : <Square size={22} />}
                                    <span>Tümünü Seç ({pendingRecords.length})</span>
                                </button>
                                {selectedRecordIds.length > 0 && (
                                    <button onClick={handleBulkApproveSelected} className="bg-green-600 text-white px-8 py-2.5 rounded-xl text-sm font-black shadow-xl flex items-center gap-2 hover:bg-green-700 transition-all transform active:scale-95">
                                        <CheckCircle size={18} /> Seçili {selectedRecordIds.length} Kaydı Onayla
                                    </button>
                                )}
                            </div>
                        )}
                        {pendingRecords.length === 0 ? (
                            <div className="text-center py-32 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                                <CheckCircle size={48} className="mx-auto text-gray-200 mb-4" />
                                <p className="text-gray-400 font-bold">Onay bekleyen tarih girişi bulunmuyor.</p>
                            </div>
                        ) : pendingRecords.map(rec => (
                            <div key={rec.id} className={`bg-white p-5 rounded-2xl shadow-sm border-l-8 transition-all flex items-center gap-5 ${selectedRecordIds.includes(rec.id) ? 'border-brand-600 bg-brand-50/10' : 'border-yellow-400'}`}>
                                <button onClick={() => toggleRecordSelection(rec.id)} className={`transition-all ${selectedRecordIds.includes(rec.id) ? 'text-brand-600' : 'text-gray-300'}`}>
                                    {selectedRecordIds.includes(rec.id) ? <CheckSquare size={24} /> : <Square size={24} />}
                                </button>
                                <div className="flex-1">
                                    <div className="font-black text-gray-800 text-lg uppercase">{rec.employeeName}</div>
                                    <div className="flex items-center gap-4 mt-1.5 text-xs">
                                        <span className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg font-black uppercase border border-indigo-100">{RECORD_CONFIGS[rec.type].label}</span>
                                        <span className="text-gray-500 font-bold">İşlem: <b className="text-gray-800">{rec.date}</b></span>
                                    </div>
                                </div>
                                <div className="flex gap-3">
                                    <button onClick={() => handleAction(rec.id, rejectRecord, {id: currentUser!.id, name: currentUser!.name, role: currentUser!.role})} className="p-3 text-red-400 hover:text-red-600 rounded-xl"><X size={20}/></button>
                                    <button onClick={() => handleAction(rec.id, approveRecord, {id: currentUser!.id, name: currentUser!.name, role: currentUser!.role})} className="p-3 bg-green-600 text-white rounded-xl hover:bg-green-700"><Check size={20}/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'USERS' && (
                    <div className="space-y-4">
                        {pendingUsers.length === 0 ? <p className="text-center py-20 text-gray-400 font-bold italic">Yeni başvuru bulunmuyor.</p> : pendingUsers.map(u => (
                            <div key={u.id} className="bg-white p-5 rounded-2xl shadow-sm border-l-8 border-blue-400 flex justify-between items-center">
                                <div><div className="font-black text-gray-800 text-lg uppercase">{u.name}</div><div className="text-[11px] font-black text-blue-600 uppercase mt-1 bg-blue-50 px-2 py-0.5 rounded-md inline-block">{ROLE_LABELS[u.role]}</div></div>
                                <div className="flex gap-3"><button onClick={() => handleAction(u.id, rejectUser, {id: currentUser!.id, name: currentUser!.name})} className="px-5 py-2 text-red-600 hover:bg-red-50 rounded-xl text-xs font-black">REDDET</button><button onClick={() => handleAction(u.id, approveUser, {id: currentUser!.id, name: currentUser!.name})} className="px-5 py-2 bg-brand-600 text-white rounded-xl hover:bg-brand-700 text-xs font-black">ONAYLA</button></div>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'UNITS' && (
                    <div className="space-y-6">
                        <div className="bg-brand-50 p-6 rounded-3xl border border-brand-100 flex items-start gap-4">
                            <ShieldAlert className="text-brand-600 flex-shrink-0" size={24} />
                            <div className="text-sm text-brand-800 leading-relaxed font-bold">
                                <p className="uppercase text-[11px] mb-1">Birim Gizlilik Ayarları:</p>
                                Buradan birimleri kısıtlayabilir veya özel ayarlarını sistemden tamamen kaldırabilirsiniz.
                            </div>
                        </div>

                        <div className="bg-white rounded-3xl shadow-md border border-gray-100 overflow-hidden">
                            <table className="min-w-full divide-y divide-gray-50">
                                <thead className="bg-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                    <tr>
                                        <th className="px-6 py-5 text-left">BİRİM / DAİRE BAŞKANLIĞI ADI</th>
                                        <th className="px-6 py-5 text-center">GÖRÜNÜRLÜK DURUMU</th>
                                        <th className="px-6 py-5 text-right">EYLEM</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-50">
                                    {unitSettings.map(unit => (
                                        <tr key={unit.workplaceName} className="hover:bg-gray-50 transition-colors">
                                            <td className="px-6 py-5">
                                                <div className="flex items-center gap-3">
                                                    <div className={`p-2 rounded-lg ${unit.isRestricted ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'}`}>
                                                        {unit.isRestricted ? <Lock size={18} /> : <Unlock size={18} />}
                                                    </div>
                                                    <span className="font-black text-gray-800 uppercase text-sm tracking-tight">{unit.workplaceName}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-5 text-center">
                                                {unit.isRestricted ? (
                                                    <span className="px-3 py-1 bg-amber-50 text-amber-700 text-[10px] font-black rounded-lg border border-amber-200 uppercase">KISITLI ERİŞİM</span>
                                                ) : (
                                                    <span className="px-3 py-1 bg-green-50 text-green-700 text-[10px] font-black rounded-lg border border-green-200 uppercase">HERKESE AÇIK</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-5 text-right">
                                                <div className="flex justify-end gap-2">
                                                    <button 
                                                        onClick={() => toggleUnitStatus(unit.workplaceName, unit.isRestricted)}
                                                        disabled={processingId === unit.workplaceName}
                                                        className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all transform active:scale-95 flex items-center gap-2
                                                            ${unit.isRestricted ? 'bg-green-600 text-white' : 'bg-amber-500 text-white'}`}
                                                    >
                                                        {unit.isRestricted ? 'ERİŞİME AÇ' : 'ERİŞİMİ KISITLA'}
                                                    </button>
                                                    <button 
                                                        onClick={() => handleDeleteUnitSetting(unit.workplaceName)}
                                                        className="p-2 text-gray-400 hover:text-red-600 transition-all"
                                                        title="Ayar Sil"
                                                    >
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {activeTab === 'MANAGEMENT' && (
                    <div className="bg-white rounded-3xl shadow-md border border-gray-100 overflow-hidden overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-100">
                            <thead className="bg-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                <tr>
                                    <th className="px-6 py-5 text-left">KULLANICI PROFİLİ</th>
                                    <th className="px-6 py-5 text-left">YETKİ SEVİYESİ (ROL)</th>
                                    <th className="px-6 py-5 text-left">ŞİFRE YÖNETİMİ</th>
                                    <th className="px-6 py-5 text-center">VERİ ERİŞİMİ</th>
                                    <th className="px-6 py-5 text-right">EYLEMLER</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 text-sm">
                                {allUsers.map(u => {
                                    const isSelf = u.id === currentUser?.id;
                                    const hasChanges = !!tempUserData[u.id];
                                    
                                    return (
                                        <tr key={u.id} className="hover:bg-gray-50 transition-colors group">
                                            <td className="px-6 py-5">
                                                <div className="font-black text-gray-800 uppercase">{u.name} {isSelf && <span className="text-[9px] bg-brand-100 text-brand-600 px-1.5 py-0.5 rounded ml-1">SİZ</span>}</div>
                                                <div className="text-xs text-gray-400">@{u.username}</div>
                                            </td>
                                            <td className="px-6 py-5">
                                                <select 
                                                    disabled={isSelf}
                                                    value={tempUserData[u.id]?.role || u.role}
                                                    onChange={(e) => handleTempDataChange(u.id, 'role', e.target.value)}
                                                    className={`text-[10px] font-black px-3 py-1.5 rounded-xl border outline-none transition-all cursor-pointer bg-white
                                                        ${tempUserData[u.id]?.role ? 'border-brand-500 ring-1 ring-brand-500' : 'border-gray-200'}`}
                                                >
                                                    {Object.entries(ROLE_LABELS).map(([key, label]) => (
                                                        <option key={key} value={key}>{label}</option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td className="px-6 py-5">
                                                <div className="flex items-center gap-2 max-w-[150px]">
                                                    <input 
                                                        type={visiblePasswords[u.id] ? "text" : "password"}
                                                        defaultValue={u.password}
                                                        onChange={(e) => handleTempDataChange(u.id, 'password', e.target.value)}
                                                        className={`w-full px-3 py-1.5 bg-gray-50 border rounded-xl text-xs font-bold outline-none focus:ring-1 focus:ring-brand-500
                                                            ${tempUserData[u.id]?.password ? 'border-brand-500 bg-brand-50' : 'border-gray-100'}`}
                                                    />
                                                    <button 
                                                        onClick={() => togglePasswordVisibility(u.id)}
                                                        className="p-1.5 text-gray-400 hover:text-brand-600 transition-colors"
                                                        title="Göster/Gizle"
                                                    >
                                                        {visiblePasswords[u.id] ? <EyeOff size={16}/> : <Eye size={16}/>}
                                                    </button>
                                                </div>
                                            </td>
                                            <td className="px-6 py-5 text-center">
                                                {(u.role === 'SPECIALIST' || u.role === 'DOCTOR') ? (
                                                    <button 
                                                        onClick={() => handleToggleAccess(u.id, !!u.isAccessEnabled)}
                                                        className={`flex items-center gap-2 mx-auto px-4 py-2 rounded-xl text-[10px] font-black transition-all ${u.isAccessEnabled ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}
                                                    >
                                                        {processingId === u.id ? <Loader2 size={14} className="animate-spin" /> : (u.isAccessEnabled ? <ToggleRight size={18}/> : <ToggleLeft size={18}/>)}
                                                        {u.isAccessEnabled ? 'ERİŞİM AKTİF' : 'ERİŞİM KAPALI'}
                                                    </button>
                                                ) : (
                                                    <span className="text-[10px] text-gray-300 font-black italic uppercase">YASAL YETKİLİ</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-5 text-right">
                                                <div className="flex justify-end gap-1">
                                                    {hasChanges && (
                                                        <button 
                                                            onClick={() => saveUserChanges(u.id)}
                                                            className="p-2 text-green-600 bg-green-50 rounded-xl hover:bg-green-100 transition-all animate-pulse"
                                                            title="Değişiklikleri Kaydet"
                                                        >
                                                            <Save size={18}/>
                                                        </button>
                                                    )}
                                                    <button 
                                                        onClick={() => handleDeleteUser(u.id)} 
                                                        disabled={isSelf} 
                                                        className={`p-2 transition-all rounded-xl ${isSelf ? 'opacity-0' : 'text-gray-300 hover:text-red-600 hover:bg-red-50'}`} 
                                                        title="Kullanıcıyı Sil"
                                                    >
                                                        <Trash2 size={18}/>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}

                {activeTab === 'LOGS' && (
                    <div className="space-y-4">
                        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
                            <div className="relative flex-1 w-full">
                                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
                                <input type="text" placeholder="İşlem veya kullanıcı ara..." className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-100 bg-gray-50 outline-none focus:ring-2 focus:ring-brand-500 font-bold text-sm" value={logSearch} onChange={(e) => setLogSearch(e.target.value)} />
                            </div>
                            <button onClick={loadData} className="px-6 py-2 bg-brand-50 text-brand-700 rounded-xl text-[10px] font-black uppercase hover:bg-brand-100 transition-all flex items-center gap-2">
                                <Activity size={14} /> GÜNCELLE
                            </button>
                        </div>
                        <div className="bg-white rounded-3xl shadow-md border border-gray-100 overflow-hidden overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-50">
                                <thead className="bg-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                                    <tr><th className="px-6 py-5 text-left">İŞLEM SAATİ</th><th className="px-6 py-5 text-left">KULLANICI</th><th className="px-6 py-5 text-left">EYLEM</th><th className="px-6 py-5 text-left">DETAYLAR</th></tr>
                                </thead>
                                <tbody className="divide-y divide-gray-50 text-[13px] font-bold">
                                    {filteredLogs.length === 0 ? (
                                        <tr><td colSpan={4} className="text-center py-20 text-gray-300 italic">Kayıtlı log bulunamadı.</td></tr>
                                    ) : filteredLogs.map(log => (
                                        <tr key={log.id} className="hover:bg-gray-50/50 transition-colors">
                                            <td className="px-6 py-4 whitespace-nowrap"><div className="flex items-center gap-2 text-gray-400 font-mono"><Clock size={14} />{new Date(log.timestamp).toLocaleString('tr-TR')}</div></td>
                                            <td className="px-6 py-4">{log.userName}</td>
                                            <td className="px-6 py-4"><span className="px-2.5 py-1 rounded-lg text-[10px] font-black uppercase border tracking-tight bg-brand-50 text-brand-700">{log.action}</span></td>
                                            <td className="px-6 py-4 text-gray-500 font-medium">{log.details}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
