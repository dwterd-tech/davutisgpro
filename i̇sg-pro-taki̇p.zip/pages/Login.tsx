
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, Lock, User, CheckCircle, UserPlus, ArrowLeft, Briefcase, Phone, FileDigit, Info } from 'lucide-react';
import { HazardClass, Role } from '../types';
import { ROLE_LABELS } from '../constants';
import { isValidTC } from '../services/mockDataService';

export const Login: React.FC = () => {
  const [isRegistering, setIsRegistering] = useState(false);
  
  // Login State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  // Register State
  const [fullName, setFullName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<Role>('PERSONNEL');
  
  // Extended Employee Details for Registration
  const [tcNumber, setTcNumber] = useState('');
  const [workplaceName, setWorkplaceName] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [hazardClass, setHazardClass] = useState<HazardClass>('TEHLIKELI');
  const [phone, setPhone] = useState('');

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);

    try {
      const result = await login(username, password);
      if (result.success) {
        navigate('/');
      } else {
        setError(result.message || 'Giriş başarısız.');
      }
    } catch (err) {
      setError('Bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    // Validation
    if (!isValidTC(tcNumber)) {
        setError("Geçersiz TC Kimlik Numarası! 11 haneli olmalı ve sadece rakam içermelidir.");
        return;
    }

    setLoading(true);

    try {
      const result = await register(regUsername, regPassword, fullName, selectedRole, {
          tcNumber,
          workplaceName,
          jobTitle,
          hazardClass,
          phone
      });
      if (result.success) {
        setSuccessMsg(result.message || 'Kayıt başarılı.');
        // Clear form and switch to login
        setUsername('');
        setPassword('');
        setIsRegistering(false);
      } else {
        setError(result.message || 'Kayıt başarısız.');
      }
    } catch (err) {
      setError('Bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className={`bg-white rounded-[2rem] shadow-2xl w-full ${isRegistering ? 'max-w-2xl' : 'max-w-md'} overflow-hidden transition-all duration-500 border border-slate-100`}>
        {/* Header */}
        <div className="bg-brand-900 p-10 text-center relative overflow-hidden">
          {/* Decorative Elements */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-brand-700 rounded-full opacity-20 blur-xl"></div>
          <div className="absolute -bottom-10 -left-10 w-24 h-24 bg-brand-500 rounded-full opacity-10 blur-xl"></div>
          
          {isRegistering && (
             <button onClick={() => { setIsRegistering(false); setError(''); setSuccessMsg(''); }} className="absolute left-6 top-6 text-brand-200 hover:text-white transition-all bg-white/10 p-2 rounded-xl">
                 <ArrowLeft className="w-5 h-5" />
             </button>
          )}
          <div className="inline-flex items-center justify-center w-20 h-20 bg-brand-800 rounded-3xl mb-6 shadow-inner border border-brand-700/50">
            <ShieldCheck className="w-10 h-10 text-green-400" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight uppercase">
              {isRegistering ? 'Kayıt Ol' : 'İSG PRO TAKİP'}
          </h1>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2 opacity-90">
              {isRegistering ? 'Sisteme katılarak güvenliği artırın' : 'Güvenli Gelecek İçin Profesyonel Takip'}
          </p>
        </div>

        {/* Content */}
        <div className="p-10">
            {/* Feedback Messages */}
            {error && (
              <div className="mb-6 bg-red-50 text-red-600 text-[11px] font-black p-4 rounded-2xl border border-red-100 text-center animate-in fade-in slide-in-from-top-2 duration-300 uppercase tracking-tight">
                 {error}
              </div>
            )}
            {successMsg && (
              <div className="mb-6 bg-green-50 text-green-600 text-[11px] font-black p-4 rounded-2xl border border-green-100 text-center flex items-center justify-center animate-in fade-in slide-in-from-top-2 duration-300 uppercase tracking-tight">
                  <CheckCircle className="w-4 h-4 mr-2"/>
                  {successMsg}
              </div>
            )}

            {!isRegistering ? (
                // --- LOGIN FORM ---
                <>
                    <form onSubmit={handleLogin} className="space-y-6">
                        <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Kullanıcı Adı</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <User className="h-4 w-4 text-gray-400" />
                            </div>
                            <input
                            type="text"
                            required
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="block w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all font-bold text-sm outline-none"
                            placeholder="Kullanıcı adınız"
                            />
                        </div>
                        </div>

                        <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Şifre</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Lock className="h-4 w-4 text-gray-400" />
                            </div>
                            <input
                            type="password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="block w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all font-bold text-sm outline-none"
                            placeholder="••••••••"
                            />
                        </div>
                        </div>

                        <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center items-center gap-2 py-4 px-4 bg-brand-600 hover:bg-brand-700 text-white rounded-2xl shadow-xl shadow-brand-100 text-xs font-black uppercase tracking-widest transition-all transform active:scale-95 disabled:opacity-50"
                        >
                        {loading ? 'İşleniyor...' : 'Sisteme Giriş Yap'}
                        </button>
                    </form>
                    
                    <div className="mt-8 text-center pt-4">
                        <p className="text-xs text-gray-400 font-bold">Hesabınız yok mu?</p>
                        <button 
                            onClick={() => { setIsRegistering(true); setError(''); setSuccessMsg(''); }}
                            className="mt-3 inline-flex items-center text-brand-600 hover:text-brand-800 font-black text-xs uppercase tracking-widest group"
                        >
                            <UserPlus className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform"/>
                            Hemen Kayıt Olun
                        </button>
                    </div>
                </>
            ) : (
                // --- REGISTER FORM ---
                <form onSubmit={handleRegister} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Sol Kolon: Hesap Bilgileri */}
                        <div className="space-y-5">
                            <h3 className="font-black text-[10px] text-brand-600 border-b border-brand-50 pb-2 uppercase tracking-widest">Hesap Bilgileri</h3>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Ad Soyad</label>
                                <input required type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="Tam Adınız" />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Kullanıcı Adı</label>
                                <input required type="text" value={regUsername} onChange={(e) => setRegUsername(e.target.value)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="Kullanıcı adı" />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Şifre</label>
                                <input required type="password" value={regPassword} onChange={(e) => setRegPassword(e.target.value)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="Şifreniz" minLength={6} />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Rol Seçimi</label>
                                <select value={selectedRole} onChange={(e) => setSelectedRole(e.target.value as Role)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none appearance-none">
                                    <option value="PERSONNEL">{ROLE_LABELS['PERSONNEL']}</option>
                                    <option value="SPECIALIST">{ROLE_LABELS['SPECIALIST']}</option>
                                    <option value="DOCTOR">{ROLE_LABELS['DOCTOR']}</option>
                                    <option value="ADMIN">{ROLE_LABELS['ADMIN']}</option>
                                    <option value="OPERATOR">{ROLE_LABELS['OPERATOR']}</option>
                                </select>
                            </div>
                        </div>
                        
                        {/* Sağ Kolon: Personel Bilgileri */}
                        <div className="space-y-5">
                            <h3 className="font-black text-[10px] text-brand-600 border-b border-brand-50 pb-2 uppercase tracking-widest">Personel Detayları</h3>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">TC Kimlik No</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><FileDigit className="h-4 w-4 text-gray-300" /></div>
                                    <input required type="text" maxLength={11} value={tcNumber} onChange={(e) => setTcNumber(e.target.value)} className="block w-full pl-10 px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="11 Haneli TC" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">İş Yeri / Birim</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Briefcase className="h-4 w-4 text-gray-300" /></div>
                                    <input required type="text" value={workplaceName} onChange={(e) => setWorkplaceName(e.target.value)} className="block w-full pl-10 px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="Şube / Ofis Adı" />
                                </div>
                            </div>
                             <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Görevi / Unvan</label>
                                <input required type="text" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="Unvan" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Sınıfı</label>
                                    <select value={hazardClass} onChange={(e) => setHazardClass(e.target.value as HazardClass)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none appearance-none">
                                        <option value="AZ_TEHLIKELI">Az Tehlikeli</option>
                                        <option value="TEHLIKELI">Tehlikeli</option>
                                        <option value="COK_TEHLIKELI">Çok Tehlikeli</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Telefon</label>
                                    <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} className="block w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-brand-500 font-bold text-sm outline-none" placeholder="05..." />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-brand-50/50 p-4 rounded-2xl border border-brand-100 flex items-start gap-3">
                        <Info className="text-brand-600 flex-shrink-0" size={18} />
                        <p className="text-[10px] text-brand-800 font-bold leading-relaxed"><strong>BİLGİLENDİRME:</strong> Kaydınız Yönetici tarafından onaylandığında, girdiğiniz bilgilerle otomatik olarak Personel Sicil Kartınız oluşturulacaktır.</p>
                    </div>

                    <div className="pt-4 flex flex-col gap-4">
                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full py-4 bg-brand-600 hover:bg-brand-700 text-white rounded-2xl text-xs font-black shadow-xl shadow-brand-100 transition-all uppercase tracking-widest flex items-center justify-center gap-2"
                        >
                            {loading ? 'İşleniyor...' : 'Kayıt Başvurusunu Tamamla'}
                        </button>
                        
                        <button 
                            type="button"
                            onClick={() => setIsRegistering(false)}
                            className="w-full text-center text-[10px] font-black text-gray-400 hover:text-gray-800 transition-colors uppercase tracking-widest"
                        >
                            Giriş Ekranına Dön
                        </button>
                    </div>
                </form>
            )}
        </div>
      </div>

      {/* FOOTER: Ownership & Copyright Information */}
      <footer className="mt-10 text-center max-w-lg mx-auto space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          <p className="text-[11px] text-gray-400 font-bold leading-relaxed px-4">
              Bu yazılım (Davut Erdoğan İSG PRO TAKİP) geliştiricisi <b>Davut Erdoğan</b>’a aittir. <br className="hidden sm:block" />
              İzinsiz kullanım ve dağıtım hukuki sorumluluk doğurur.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-6 pt-2">
              <span className="text-[10px] font-black text-brand-600/50 uppercase tracking-widest">© 2024 Tüm Hakları Davut Erdoğan'a Aittir</span>
              <div className="flex items-center gap-2 text-brand-700 bg-white px-3 py-1 rounded-full shadow-sm border border-brand-50">
                  <Phone size={12} />
                  <span className="text-[11px] font-black">0 546 144 00 61</span>
              </div>
          </div>
      </footer>
    </div>
  );
};
