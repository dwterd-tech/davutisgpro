
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getDashboardStats, exportToExcel, getUniqueWorkplaces, getEmployeesWithStatus } from '../services/mockDataService';
import { DashboardStats, HazardClass, Employee } from '../types';
import { ResponsiveContainer, PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';
import { AlertTriangle, ShieldAlert, CheckCircle, Clock, FileText, Filter, Download, FileSpreadsheet } from 'lucide-react';
import { HAZARD_LABELS, EXCEL_HEADERS } from '../constants';
import { Link } from 'react-router-dom';

export const Dashboard: React.FC = () => {
  const { role, currentUser } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [workplaces, setWorkplaces] = useState<string[]>([]);
  
  // Filters
  const [workplaceFilter, setWorkplaceFilter] = useState('');
  const [hazardFilter, setHazardFilter] = useState<HazardClass | ''>('');
  const [statusFilter, setStatusFilter] = useState<'RED' | 'YELLOW' | 'GREEN' | ''>('');
  
  const [exporting, setExporting] = useState(false);

  const loadData = async () => {
      const [statData, wpData] = await Promise.all([
          getDashboardStats({
              workplace: workplaceFilter,
              hazardClass: hazardFilter,
          }, currentUser || undefined),
          getUniqueWorkplaces()
      ]);
      setStats(statData);
      setWorkplaces(wpData);
  };

  useEffect(() => {
    loadData();
  }, [workplaceFilter, hazardFilter, statusFilter]);

  const handleExportFiltered = async () => {
      setExporting(true);
      const filteredPersonnel = await getEmployeesWithStatus({
          workplace: workplaceFilter,
          hazardClass: hazardFilter,
          status: statusFilter
      }, currentUser || undefined);
      
      const exportData = filteredPersonnel.map(emp => ({
          [EXCEL_HEADERS[0]]: emp.fullName,
          [EXCEL_HEADERS[1]]: emp.tcNumber,
          [EXCEL_HEADERS[2]]: emp.birthDate || '---',
          [EXCEL_HEADERS[3]]: emp.jobTitle,
          [EXCEL_HEADERS[4]]: emp.workplaceName,
          [EXCEL_HEADERS[5]]: emp.phone || '---',
          [EXCEL_HEADERS[6]]: HAZARD_LABELS[emp.hazardClass],
          [EXCEL_HEADERS[7]]: emp.trainingDue || 'Girilmemiş',
          [EXCEL_HEADERS[8]]: emp.healthDue || 'Girilmemiş',
          "RİSK DURUMU": emp.risk === 'RED' ? 'KRİTİK' : emp.risk === 'YELLOW' ? 'RİSKLİ' : 'UYGUN'
      }));
      
      const dateStr = new Date().toLocaleDateString('tr-TR').replace(/\//g, '_').replace(/\./g, '_');
      exportToExcel(exportData, `ISG_Durum_Raporu_${dateStr}`);
      setExporting(false);
  };

  if (!stats) return <div className="text-center p-20 text-brand-600 font-bold animate-pulse">Analiz Yapılıyor...</div>;

  const pieData = [
    { name: 'Uygun', value: stats.riskGreen, color: '#10b981' }, 
    { name: 'Riskli', value: stats.riskYellow, color: '#f59e0b' }, 
    { name: 'Kritik', value: stats.riskRed, color: '#ef4444' }, 
  ];

  const hasPendingItems = stats.pendingApprovals > 0 || stats.pendingUserApprovals > 0;

  return (
    <div className="space-y-6">
      {role === 'ADMIN' && hasPendingItems && (
        <div className="bg-red-50 border-l-4 border-red-500 p-5 rounded-r-2xl shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center">
            <div className="p-3 bg-red-100 rounded-xl mr-4"><ShieldAlert className="h-6 w-6 text-red-600" /></div>
            <div>
              <p className="font-black text-red-800 uppercase text-xs tracking-widest">Bekleyen İşlemler</p>
              <p className="text-sm text-red-700 font-bold mt-1">
                 {stats.pendingApprovals > 0 && <span>• {stats.pendingApprovals} Kayıt Onayı </span>}
                 {stats.pendingUserApprovals > 0 && <span>• {stats.pendingUserApprovals} Yeni Kullanıcı </span>}
              </p>
            </div>
          </div>
          <Link to="/approvals" className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black shadow-lg shadow-red-100 transition-all transform active:scale-95">
             ONAY MERKEZİNE GİT
          </Link>
        </div>
      )}

      {/* Dynamic Filters */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col lg:flex-row gap-4 items-center">
          <div className="flex items-center gap-3 text-gray-400 font-black text-[10px] uppercase tracking-widest">
              <Filter className="w-5 h-5 text-brand-500"/>
              <span>Hızlı Filtrele:</span>
          </div>
          
          <div className="flex flex-1 flex-wrap gap-3 w-full">
              <select 
                className="flex-1 min-w-[150px] border border-gray-100 rounded-xl p-3 text-xs font-black focus:ring-2 focus:ring-brand-500 outline-none bg-gray-50/50"
                value={workplaceFilter}
                onChange={(e) => setWorkplaceFilter(e.target.value)}
              >
                  <option value="">TÜM BİRİMLER ({workplaces.length})</option>
                  {workplaces.map(wp => <option key={wp} value={wp}>{wp}</option>)}
              </select>

              <select
                className="flex-1 min-w-[150px] border border-gray-100 rounded-xl p-3 text-xs font-black focus:ring-2 focus:ring-brand-500 outline-none bg-gray-50/50"
                value={hazardFilter}
                onChange={(e) => setHazardFilter(e.target.value as HazardClass)}
              >
                  <option value="">TÜM TEHLİKE SINIFLARI</option>
                  <option value="AZ_TEHLIKELI">{HAZARD_LABELS['AZ_TEHLIKELI']}</option>
                  <option value="TEHLIKELI">{HAZARD_LABELS['TEHLIKELI']}</option>
                  <option value="COK_TEHLIKELI">{HAZARD_LABELS['COK_TEHLIKELI']}</option>
              </select>

              <select
                className={`flex-1 min-w-[150px] border rounded-xl p-3 text-xs font-black outline-none transition-all
                    ${statusFilter === 'RED' ? 'bg-red-50 border-red-200 text-red-700' : 
                      statusFilter === 'YELLOW' ? 'bg-yellow-50 border-yellow-200 text-yellow-700' :
                      statusFilter === 'GREEN' ? 'bg-green-50 border-green-200 text-green-700' :
                      'bg-gray-50/50 border-gray-100 text-gray-700'}`}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
              >
                  <option value="">TÜM DURUMLAR</option>
                  <option value="RED">SÜRESİ DOLANLAR</option>
                  <option value="YELLOW">SÜRESİ YAKLAŞANLAR</option>
                  <option value="GREEN">DURUMU UYGUNLAR</option>
              </select>

              <button 
                onClick={() => {setWorkplaceFilter(''); setHazardFilter(''); setStatusFilter('');}} 
                className="px-4 text-[10px] font-black text-gray-400 hover:text-red-500 uppercase transition-colors"
              >
                SIFIRLA
              </button>
          </div>

          <button 
            onClick={handleExportFiltered}
            disabled={exporting}
            className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-xl shadow-brand-100 transition-all transform active:scale-95 whitespace-nowrap"
          >
            {exporting ? <Clock className="animate-spin" size={16}/> : <FileSpreadsheet size={16} />}
            FİLTRELENMİŞ LİSTEYİ AKTAR
          </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Filtrelenen Personel" value={stats.totalPersonnel} icon={<FileText size={24}/>} color="border-brand-500" bg="bg-brand-50" />
        <StatCard title="Kritik (Kırmızı)" value={stats.riskRed} sub="Süresi Dolan" icon={<ShieldAlert className="text-red-600" size={24}/>} color="border-red-600" bg="bg-red-50" textColor="text-red-700" />
        <StatCard title="Riskli (Sarı)" value={stats.riskYellow} sub="Yaklaşan" icon={<Clock className="text-yellow-600" size={24}/>} color="border-yellow-500" bg="bg-yellow-50" textColor="text-yellow-700" />
        <StatCard title="Güvenli (Yeşil)" value={stats.riskGreen} sub="Uygun" icon={<CheckCircle className="text-green-600" size={24}/>} color="border-green-500" bg="bg-green-50" textColor="text-green-700" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center">
          <h3 className="text-sm font-black text-gray-800 mb-6 uppercase tracking-widest">Uyumluluk Grafiği</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
            <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
            </PieChart>
            </ResponsiveContainer>
         </div>
        </div>

        <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
            <h3 className="text-sm font-black text-gray-800 mb-6 flex items-center gap-2 uppercase tracking-widest">
                <FileText className="text-brand-600" />
                Yasal Takip Parametreleri
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                    <p className="text-[10px] font-black text-brand-700 mb-3 uppercase border-b pb-1">EĞİTİM (TEHLİKE BAZLI)</p>
                    <div className="space-y-2 text-xs font-bold">
                        <div className="flex justify-between"><span>Az Tehlikeli:</span> <span className="bg-white px-2 rounded">3 Yıl</span></div>
                        <div className="flex justify-between"><span>Tehlikeli:</span> <span className="bg-white px-2 rounded">2 Yıl</span></div>
                        <div className="flex justify-between"><span>Çok Tehlikeli:</span> <span className="bg-white px-2 rounded">1 Yıl</span></div>
                    </div>
                </div>
                <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100">
                    <p className="text-[10px] font-black text-brand-700 mb-3 uppercase border-b pb-1">SAĞLIK (TEHLİKE BAZLI)</p>
                    <div className="space-y-2 text-xs font-bold">
                        <div className="flex justify-between"><span>Az Tehlikeli:</span> <span className="bg-white px-2 rounded">5 Yıl</span></div>
                        <div className="flex justify-between"><span>Tehlikeli:</span> <span className="bg-white px-2 rounded">3 Yıl</span></div>
                        <div className="flex justify-between"><span>Çok Tehlikeli:</span> <span className="bg-white px-2 rounded">1 Yıl</span></div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: number; icon: React.ReactNode; color: string; bg?: string; sub?: string; textColor?: string }> = ({ title, value, icon, color, bg = 'bg-white', sub, textColor = 'text-gray-800' }) => (
  <div className={`${bg} p-6 rounded-3xl shadow-sm border-l-8 ${color} flex items-center justify-between transition-all hover:shadow-md`}>
    <div>
      <p className="text-gray-400 text-[9px] font-black uppercase tracking-widest">{title}</p>
      <p className={`text-3xl font-black ${textColor} mt-1`}>{value}</p>
      {sub && <p className="text-[10px] font-bold text-gray-400/60 mt-0.5">{sub}</p>}
    </div>
    <div className="p-3 bg-white rounded-2xl shadow-sm">{icon}</div>
  </div>
);
