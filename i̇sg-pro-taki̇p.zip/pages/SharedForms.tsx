
import React, { useEffect, useState, useRef } from 'react';
import { getSharedForms, uploadSharedForm, deleteSharedForm } from '../services/mockDataService';
import { SharedForm } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
    FileText, Upload, Download, Trash2, Search, 
    Plus, X, Loader2, AlertCircle, ShieldCheck, FileDown, 
    FileSpreadsheet, FileCode, FileArchive
} from 'lucide-react';

export const SharedForms: React.FC = () => {
    const { currentUser, role } = useAuth();
    const [forms, setForms] = useState<SharedForm[]>([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const [isUploading, setIsUploading] = useState(false);
    
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [newFormName, setNewFormName] = useState('');
    const [newFormCategory, setNewFormCategory] = useState('GENEL');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const loadForms = async () => {
        setLoading(true);
        const data = await getSharedForms();
        setForms(data);
        setLoading(false);
    };

    useEffect(() => { loadForms(); }, []);

    const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !currentUser) return;

        const allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];

        if (!allowedTypes.includes(file.type)) {
            alert("Sadece PDF, Word ve Excel dosyaları yüklenebilir.");
            return;
        }

        setIsUploading(true);
        const reader = new FileReader();
        reader.onload = async (event) => {
            const base64 = event.target?.result as string;
            try {
                await uploadSharedForm({
                    name: newFormName || file.name,
                    category: newFormCategory,
                    fileData: base64,
                    uploadedBy: currentUser.name
                }, currentUser);
                setNewFormName('');
                setShowUploadModal(false);
                await loadForms();
            } catch (err) {
                alert("Yükleme sırasında hata oluştu.");
            } finally {
                setIsUploading(false);
                if (fileInputRef.current) fileInputRef.current.value = '';
            }
        };
        reader.readAsDataURL(file);
    };

    const handleDelete = async (id: string) => {
        if (!currentUser) return;
        if (!window.confirm("Bu formu kalıcı olarak silmek istediğinize emin misiniz?")) return;
        await deleteSharedForm(id, currentUser);
        await loadForms();
    };

    const downloadForm = (form: SharedForm) => {
        const link = document.createElement('a');
        link.href = form.fileData;
        // Dosya adı uzantı içermiyorsa veriden tahmin etmeye çalış (basit kontrol)
        let fileName = form.name;
        if (!fileName.includes('.')) {
            if (form.fileData.includes('spreadsheet') || form.fileData.includes('excel')) fileName += '.xlsx';
            else if (form.fileData.includes('word') || form.fileData.includes('msword')) fileName += '.docx';
            else fileName += '.pdf';
        }
        link.download = fileName;
        link.click();
    };

    const getFileIcon = (form: SharedForm) => {
        const data = form.fileData.toLowerCase();
        const name = form.name.toLowerCase();
        
        if (data.includes('spreadsheet') || data.includes('excel') || name.endsWith('.xls') || name.endsWith('.xlsx') || name.endsWith('.csv')) {
            return <FileSpreadsheet className="text-green-600" size={32} />;
        }
        if (data.includes('word') || data.includes('msword') || name.endsWith('.doc') || name.endsWith('.docx')) {
            return <FileText className="text-blue-600" size={32} />;
        }
        return <FileText className="text-red-500" size={32} />;
    };

    const filtered = forms.filter(f => 
        f.name.toLowerCase().includes(search.toLowerCase()) || 
        f.category.toLowerCase().includes(search.toLowerCase())
    );

    const canUpload = role === 'ADMIN';
    const canDownload = role === 'ADMIN' || role === 'SPECIALIST' || role === 'DOCTOR' || role === 'OPERATOR';

    return (
        <div className="space-y-6 max-w-6xl mx-auto">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="flex items-center gap-4">
                    <div className="p-4 bg-brand-100 text-brand-600 rounded-2xl shadow-inner">
                        <FileArchive size={32} />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-gray-800 tracking-tight">Kurumsal Form Havuzu</h2>
                        <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-1">Standart PDF, Word ve Excel Dokümanları</p>
                    </div>
                </div>
                {canUpload && (
                    <button 
                        onClick={() => setShowUploadModal(true)}
                        className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white px-8 py-4 rounded-2xl text-sm font-black shadow-xl shadow-brand-100 transition-all transform active:scale-95"
                    >
                        <Plus size={20} />
                        YENİ DOKÜMAN YÜKLE
                    </button>
                )}
            </div>

            <div className="relative">
                <Search className="absolute left-4 top-4 text-gray-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Form adı veya kategori ile ara..." 
                    className="w-full pl-12 pr-4 py-4 bg-white border border-gray-100 rounded-2xl shadow-sm focus:ring-2 focus:ring-brand-500 outline-none font-bold text-sm"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {loading ? (
                    <div className="col-span-full py-20 text-center text-brand-600">
                        <Loader2 className="animate-spin mx-auto mb-4" size={48} />
                        <p className="font-black animate-pulse">DOKÜMAN LİSTESİ HAZIRLANIYOR...</p>
                    </div>
                ) : filtered.length === 0 ? (
                    <div className="col-span-full py-20 bg-white rounded-3xl border-2 border-dashed border-gray-100 text-center">
                        <AlertCircle className="mx-auto text-gray-200 mb-4" size={64} />
                        <p className="text-gray-400 font-black">Henüz hiçbir doküman yüklenmemiş.</p>
                    </div>
                ) : filtered.map(form => (
                    <div key={form.id} className="group bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:border-brand-200 hover:shadow-xl transition-all relative overflow-hidden flex flex-col justify-between h-full">
                        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none group-hover:scale-110 transition-transform">
                            {getFileIcon(form)}
                        </div>
                        
                        <div>
                            <span className="inline-block px-3 py-1 bg-brand-50 text-brand-700 text-[10px] font-black rounded-lg uppercase tracking-widest mb-4">
                                {form.category}
                            </span>
                            <div className="flex items-start gap-3">
                                <div className="mt-1">{getFileIcon(form)}</div>
                                <h3 className="text-base font-black text-gray-800 leading-tight mb-2 line-clamp-2" title={form.name}>
                                    {form.name}
                                </h3>
                            </div>
                            <div className="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase mt-2">
                                <span>{form.uploadDate.split('T')[0].split('-').reverse().join('.')}</span>
                                <span className="w-1 h-1 bg-gray-200 rounded-full"></span>
                                <span>Yükleyen: {form.uploadedBy}</span>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t border-gray-50 flex items-center justify-between">
                            {canDownload ? (
                                <button 
                                    onClick={() => downloadForm(form)}
                                    className="flex items-center gap-2 text-brand-600 hover:text-brand-800 font-black text-xs transition-colors"
                                >
                                    <FileDown size={18} />
                                    DOSYAYI İNDİR
                                </button>
                            ) : (
                                <span className="flex items-center gap-1.5 text-gray-300 font-black text-[10px]">
                                    <ShieldCheck size={14} /> SADECE GÖRÜNTÜLEME
                                </span>
                            )}
                            
                            {role === 'ADMIN' && (
                                <button 
                                    onClick={() => handleDelete(form.id)}
                                    className="p-2 text-red-200 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                                >
                                    <Trash2 size={18} />
                                </button>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 flex items-start gap-4 shadow-sm">
                <AlertCircle className="text-indigo-600 flex-shrink-0" size={24} />
                <div className="text-sm text-indigo-800 leading-relaxed font-bold">
                    <p className="uppercase text-[11px] mb-1">Desteklenen Formatlar:</p>
                    Sistemimiz kurumsal dokümanlar için <b>PDF (.pdf)</b>, <b>Word (.doc, .docx)</b> ve <b>Excel (.xls, .xlsx)</b> dosyalarını desteklemektedir. 
                    Tüm personeller güncel form listesini takip edebilir.
                </div>
            </div>

            {showUploadModal && (
                <div className="fixed inset-0 z-[100] bg-brand-900/60 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-300">
                    <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 space-y-6 animate-in zoom-in-95 duration-300">
                        <div className="flex justify-between items-center border-b pb-4">
                            <h3 className="text-xl font-black text-gray-800 uppercase tracking-tight">Yeni Doküman Yükle</h3>
                            <button onClick={() => setShowUploadModal(false)} className="text-gray-400 hover:text-gray-900 transition-colors">
                                <X size={24} />
                            </button>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Doküman Adı (Opsiyonel)</label>
                                <input 
                                    type="text" 
                                    placeholder="Görünecek isim girin..."
                                    className="w-full border-2 border-gray-100 rounded-xl p-3 text-sm font-bold focus:ring-2 focus:ring-brand-500 outline-none"
                                    value={newFormName}
                                    onChange={(e) => setNewFormName(e.target.value)}
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Kategori</label>
                                <select 
                                    className="w-full border-2 border-gray-100 rounded-xl p-3 text-sm font-bold focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                                    value={newFormCategory}
                                    onChange={(e) => setNewFormCategory(e.target.value)}
                                >
                                    <option value="GENEL">GENEL DOKÜMANLAR</option>
                                    <option value="RİSK ANALİZİ">RİSK ANALİZLERİ</option>
                                    <option value="TALİMAT">TALİMATLAR & PROSEDÜRLER</option>
                                    <option value="EĞİTİM">EĞİTİM SUNUMLARI</option>
                                    <option value="SAĞLIK">SAĞLIK PARAMETRELERİ</option>
                                    <option value="ACİL DURUM">ACİL DURUM PLANLARI</option>
                                    <option value="TABLO">HESAPLAMA TABLOLARI (EXCEL)</option>
                                </select>
                            </div>
                            
                            <div className="pt-4">
                                <input type="file" ref={fileInputRef} onChange={handleUpload} className="hidden" accept=".pdf,.doc,.docx,.xls,.xlsx" />
                                <button 
                                    onClick={() => fileInputRef.current?.click()}
                                    disabled={isUploading}
                                    className="w-full bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl text-xs font-black shadow-xl shadow-brand-100 flex items-center justify-center gap-3 transition-all"
                                >
                                    {isUploading ? <Loader2 className="animate-spin" size={20} /> : <Upload size={20} />}
                                    {isUploading ? 'DOSYA İŞLENİYOR...' : 'DOSYA SEÇ (PDF/WORD/EXCEL)'}
                                </button>
                                <p className="text-[9px] text-gray-400 text-center mt-3 font-bold uppercase italic">Maksimum dosya boyutu: 10MB</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
