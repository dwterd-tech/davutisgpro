
import React, { useState } from 'react';
import { RecordTypeKey, HazardClass } from '../types';
import { createRecord } from '../services/mockDataService';
import { useAuth } from '../context/AuthContext';
import { RECORD_CONFIGS, HAZARD_LABELS } from '../constants';
import { AlertTriangle, Lock } from 'lucide-react';

interface Props {
  employeeId: string;
  hazardClass: HazardClass;
  onSuccess: () => void;
  onCancel: () => void;
}

export const RecordForm: React.FC<Props> = ({ employeeId, hazardClass, onSuccess, onCancel }) => {
  const { currentUser, role } = useAuth();

  const availableTypes = (Object.keys(RECORD_CONFIGS) as RecordTypeKey[]).filter(key => 
    role === 'ADMIN' || RECORD_CONFIGS[key].authorizedRole === role
  );

  const [type, setType] = useState<RecordTypeKey>(availableTypes[0]);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);

  if (availableTypes.length === 0) {
    return (
        <div className="p-8 bg-white rounded-3xl shadow-2xl text-center border border-gray-100">
            <AlertTriangle className="mx-auto text-red-500 mb-4" size={48} />
            <p className="text-red-600 font-black uppercase text-sm tracking-widest">Yetkisiz Erişim</p>
            <p className="text-xs text-gray-500 mt-2 font-medium">Rolünüz bu işlem için yetkilendirilmemiş.</p>
            <button onClick={onCancel} className="mt-6 w-full py-3 bg-gray-100 rounded-xl font-black text-xs">KAPAT</button>
        </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    try {
      // CreateRecord içerisinde tarih normalizasyonu yapılıyor (GG.AA.YYYY)
      await createRecord({
        employeeId,
        type,
        date, // HTML inputtan gelen YYYY-MM-DD
        performer: currentUser.name,
        createdBy: currentUser.id,
      }, hazardClass, { id: currentUser.id, name: currentUser.name, role: currentUser.role });
      
      onSuccess();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const currentConfig = RECORD_CONFIGS[type];
  const nextPeriod = currentConfig.periodYears[hazardClass];

  return (
    <div className="bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 space-y-6">
      <div className="flex items-center gap-3 border-b pb-4">
          <div className="p-2 bg-brand-100 rounded-lg text-brand-600"><Lock size={20}/></div>
          <div>
            <h3 className="text-lg font-black text-gray-800 tracking-tight">Kayıt Giriş Formu</h3>
            <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{role} YETKİSİYLE</p>
          </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">İşlem Türü</label>
            <div className="grid grid-cols-1 gap-2">
                {availableTypes.map(t => (
                    <button 
                        key={t}
                        type="button"
                        onClick={() => setType(t)}
                        className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all ${type === t ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-gray-50 bg-gray-50/50 text-gray-400'}`}
                    >
                        <span className="text-xs font-black">{RECORD_CONFIGS[t].label}</span>
                        <div className={`w-4 h-4 rounded-full border-2 ${type === t ? 'bg-brand-600 border-brand-600' : 'border-gray-200'}`} />
                    </button>
                ))}
            </div>
        </div>

        <div className="bg-indigo-50/50 p-4 rounded-2xl text-[11px] font-bold text-indigo-800 flex justify-between">
            <span>Periyot: {HAZARD_LABELS[hazardClass]}</span>
            <span className="font-black">+{nextPeriod} Yıl</span>
        </div>

        <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">İşlem Tarihi</label>
            <input 
                type="date" 
                required
                className="w-full bg-gray-50 border-none p-4 rounded-2xl outline-none focus:ring-2 focus:ring-brand-500 font-black text-sm"
                value={date}
                onChange={(e) => setDate(e.target.value)}
            />
        </div>

        <div className="flex gap-3 pt-4">
          <button type="button" onClick={onCancel} className="flex-1 py-4 text-xs font-black text-gray-400 hover:text-gray-600">VAZGEÇ</button>
          <button type="submit" disabled={loading} className="flex-[2] bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl text-xs font-black shadow-xl shadow-brand-100 transition-all transform active:scale-95">
            {loading ? 'İŞLENİYOR...' : 'ONAYA GÖNDER'}
          </button>
        </div>
      </form>
    </div>
  );
};
