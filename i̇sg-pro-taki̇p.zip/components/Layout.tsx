
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, Users, FileCheck, LogOut, ShieldCheck, Menu, X, UserCircle, FileSpreadsheet, FolderTree, Landmark, Phone } from 'lucide-react';
import { ROLE_LABELS } from '../constants';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, logout, role } = useAuth();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path ? 'bg-brand-700 text-white shadow-lg' : 'text-brand-100 hover:bg-brand-700/50 hover:text-white';
  const closeSidebar = () => setIsSidebarOpen(false);

  // Menu Permissions
  const isPersonnel = role === 'PERSONNEL';
  const showDashboard = !isPersonnel;
  const showPersonnelList = !isPersonnel;
  const showApprovals = role === 'ADMIN'; 
  const showUnitAssignments = role === 'ADMIN'; // Sadece Admin görür
  const showTemplates = role === 'ADMIN' || role === 'SPECIALIST' || role === 'DOCTOR';
  const showMyProfile = isPersonnel;

  return (
    <div className="flex h-screen bg-slate-100 font-sans overflow-hidden">
      {isSidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm lg:hidden" onClick={closeSidebar}></div>
      )}

      <aside className={`
        fixed lg:static inset-y-0 left-0 z-30 w-72 bg-brand-900 text-white flex flex-col shadow-2xl transform transition-transform duration-300 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-8 flex items-center justify-between border-b border-brand-800">
          <div className="flex items-center space-x-3">
            <div className="bg-brand-500 p-2 rounded-xl shadow-lg shadow-brand-500/20">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-black tracking-tighter italic">İSG PRO TAKİP</span>
          </div>
          <button onClick={closeSidebar} className="lg:hidden text-brand-300 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="flex-1 p-5 space-y-2 overflow-y-auto custom-scrollbar">
          {showDashboard && (
            <Link onClick={closeSidebar} to="/" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/')}`}>
              <LayoutDashboard className="w-5 h-5" />
              <span>Durum Paneli</span>
            </Link>
          )}

          {showMyProfile && (
             <Link onClick={closeSidebar} to="/my-profile" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/my-profile')}`}>
                <UserCircle className="w-5 h-5" />
                <span>Sicil Kartım</span>
             </Link>
          )}

          <Link onClick={closeSidebar} to="/shared-forms" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/shared-forms')}`}>
            <FolderTree className="w-5 h-5" />
            <span>Form Havuzu</span>
          </Link>

          {showPersonnelList && (
            <Link onClick={closeSidebar} to="/personnel" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/personnel')}`}>
              <Users className="w-5 h-5" />
              <span>Personel Takibi</span>
            </Link>
          )}

          {showUnitAssignments && (
             <Link onClick={closeSidebar} to="/unit-assignments" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/unit-assignments')}`}>
                <Landmark className="w-5 h-5" />
                <span>Birim Yetkileri</span>
             </Link>
          )}

          {showTemplates && (
            <Link onClick={closeSidebar} to="/templates" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/templates')}`}>
              <FileSpreadsheet className="w-5 h-5" />
              <span>Veri Şablonları</span>
            </Link>
          )}

          {showApprovals && (
            <Link onClick={closeSidebar} to="/approvals" className={`flex items-center space-x-3 px-5 py-3.5 rounded-2xl transition-all font-bold text-sm ${isActive('/approvals')}`}>
              <FileCheck className="w-5 h-5" />
              <span>Yönetim Paneli</span>
            </Link>
          )}
        </nav>

        {/* Sidebar Footer with Ownership Info */}
        <div className="shrink-0">
          <div className="mx-4 mb-4 p-5 bg-brand-800/50 rounded-3xl border border-brand-700">
            <div className="flex items-center space-x-3 mb-4 border-b border-brand-700 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-brand-500 flex items-center justify-center text-sm font-black shadow-lg uppercase">
                {currentUser?.name.charAt(0)}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-black truncate text-white uppercase tracking-tight">{currentUser?.name}</p>
                <p className="text-[10px] text-brand-300 truncate font-black uppercase tracking-widest">{ROLE_LABELS[role]}</p>
              </div>
              <button 
                onClick={logout}
                className="p-2 text-brand-300 hover:text-red-400 transition-colors"
                title="Çıkış"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
            
            {/* Legal Notice */}
            <div className="space-y-3 opacity-60 hover:opacity-100 transition-opacity">
              <p className="text-[9px] font-bold leading-tight text-brand-200">
                Bu yazılım Davut Erdoğan'a aittir. Tüm hakları saklıdır.
              </p>
              <div className="flex items-center gap-2 text-[10px] font-black text-brand-400">
                <Phone size={10} />
                <span>0 546 144 00 61</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white/80 backdrop-blur-md shadow-sm h-20 flex items-center justify-between px-6 lg:px-10 z-10 shrink-0 border-b border-slate-200">
           <div className="flex items-center">
             <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden mr-4 text-slate-400 hover:text-brand-600 focus:outline-none bg-slate-50 p-2 rounded-xl">
               <Menu className="w-6 h-6" />
             </button>
             <h1 className="text-lg lg:text-2xl font-black text-slate-800 tracking-tight uppercase">
               {location.pathname === '/' && 'Kurumsal Durum Özeti'}
               {location.pathname === '/personnel' && 'Personel Veri Bankası'}
               {location.pathname === '/approvals' && 'Sistem Yönetim Merkezi'}
               {location.pathname === '/my-profile' && 'Kişisel Sicil Kartı'}
               {location.pathname === '/templates' && 'Veri Transfer Araçları'}
               {location.pathname === '/shared-forms' && 'Kurumsal Dokümantasyon'}
               {location.pathname === '/unit-assignments' && 'Yetkilendirme Matrisi'}
               {location.pathname.startsWith('/personnel/') && 'Personel Detay Görünümü'}
             </h1>
           </div>
           
           <div className="hidden sm:flex items-center gap-4">
              <div className="flex flex-col items-end">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sistem Durumu</span>
                <span className="flex items-center gap-1.5 text-[11px] font-black text-green-600 uppercase">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                  Çevrimiçi (Aktif)
                </span>
              </div>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 lg:p-10 bg-slate-50 custom-scrollbar">
          {children}
        </div>
      </main>
    </div>
  );
};
