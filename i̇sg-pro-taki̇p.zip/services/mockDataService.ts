
import { Employee, ISGRecord, AuditLog, DashboardStats, HazardClass, RecordTypeKey, User, Role, EmployeeDocument, SharedForm, UnitSetting, UnitAssignment } from "../types";
import { RECORD_CONFIGS, EXCEL_HEADERS } from "../constants";

// --- PERSISTENCE HELPERS ---
const loadFromStorage = (key: string, defaultData: any) => {
  try {
    const stored = localStorage.getItem(key);
    if (!stored || stored === 'undefined' || stored === 'null') return defaultData;
    return JSON.parse(stored);
  } catch (e) {
    return defaultData;
  }
};

const saveToStorage = (key: string, data: any) => {
  localStorage.setItem(key, JSON.stringify(data));
};

// --- AUDIT LOGGING SYSTEM ---
export const logAction = async (user: { id: string, name: string }, action: string, details: string) => {
    let logs: AuditLog[] = loadFromStorage('isg_db_logs', []);
    const newLog: AuditLog = {
        id: `log-${Date.now()}-${Math.random()}`,
        userId: user.id,
        userName: user.name,
        action,
        details,
        timestamp: new Date().toISOString()
    };
    logs.unshift(newLog); // En yeni log en üstte
    if (logs.length > 1000) logs = logs.slice(0, 1000); // Max 1000 log
    saveToStorage('isg_db_logs', logs);
};

// --- DATE HELPERS ---
export const isValidTC = (tc: string): boolean => /^\d{11}$/.test(tc);
export const formatDateToTR = (date: Date): string => {
    const d = date.getDate().toString().padStart(2, '0');
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const y = date.getFullYear();
    return `${d}.${m}.${y}`;
};
export const parseTRDate = (dateStr: string): Date | null => {
    if (!dateStr) return null;
    const cleanStr = dateStr.trim().replace(/"/g, '');
    if (cleanStr.includes('.') || cleanStr.includes('/')) {
        const parts = cleanStr.split(/[./]/);
        if (parts.length === 3) {
            if (parts[2].length === 4) return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
            if (parts[0].length === 4) return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        }
    }
    if (cleanStr.includes('-')) {
        const parts = cleanStr.split('-');
        if (parts.length === 3 && parts[0].length === 4) return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    }
    const d = new Date(cleanStr);
    return isNaN(d.getTime()) ? null : d;
};
export const normalizeDate = (dateStr: string): string => {
    const date = parseTRDate(dateStr);
    return date ? formatDateToTR(date) : '';
};
const calculateNextDueDate = (dateStr: string, type: RecordTypeKey, hazardClass: HazardClass): string => {
  const date = parseTRDate(dateStr);
  if (!date) return '';
  const years = RECORD_CONFIGS[type].periodYears[hazardClass];
  const newDate = new Date(date);
  newDate.setFullYear(newDate.getFullYear() + years);
  return formatDateToTR(newDate);
};

// --- UNIT ASSIGNMENT SERVICES ---
export const getUnitAssignments = async (): Promise<UnitAssignment[]> => {
    return loadFromStorage('isg_db_unit_assignments', []);
};

export const assignUserToUnit = async (userId: string, workplaceName: string, admin: any): Promise<void> => {
    let assignments = await getUnitAssignments();
    if (!assignments.some(a => a.userId === userId && a.workplaceName === workplaceName)) {
        assignments.push({ userId, workplaceName });
        saveToStorage('isg_db_unit_assignments', assignments);
        logAction(admin, "BİRİM ATAMA", `${userId} ID'li kullanıcı ${workplaceName} birimine atandı.`);
    }
};

export const removeUserFromUnit = async (userId: string, workplaceName: string, admin: any): Promise<void> => {
    let assignments = await getUnitAssignments();
    assignments = assignments.filter(a => !(a.userId === userId && a.workplaceName === workplaceName));
    saveToStorage('isg_db_unit_assignments', assignments);
    logAction(admin, "BİRİM ATAMA İPTAL", `${userId} ID'li kullanıcının ${workplaceName} birim yetkisi kaldırıldı.`);
};

export const getUserAssignedUnits = async (userId: string): Promise<string[]> => {
    const assignments = await getUnitAssignments();
    return assignments.filter(a => a.userId === userId).map(a => a.workplaceName);
};

// --- UNIT SETTINGS ---
export const getUnitSettings = async (): Promise<UnitSetting[]> => {
    const units = await getUniqueWorkplaces();
    const stored: UnitSetting[] = loadFromStorage('isg_db_unit_settings', []);
    
    return units.map(u => {
        const setting = stored.find(s => s.workplaceName === u);
        return setting ? setting : { workplaceName: u, isRestricted: false };
    });
};

export const updateUnitRestriction = async (workplaceName: string, isRestricted: boolean, admin: any): Promise<void> => {
    let stored: UnitSetting[] = loadFromStorage('isg_db_unit_settings', []);
    const idx = stored.findIndex(s => s.workplaceName === workplaceName);
    if (idx > -1) stored[idx].isRestricted = isRestricted;
    else stored.push({ workplaceName, isRestricted });
    saveToStorage('isg_db_unit_settings', stored);
    logAction(admin, "BİRİM GİZLİLİK", `${workplaceName} birimi ${isRestricted ? 'KISITLI' : 'AÇIK'} hale getirildi.`);
};

export const deleteUnitSetting = async (workplaceName: string, admin: any): Promise<void> => {
    let stored: UnitSetting[] = loadFromStorage('isg_db_unit_settings', []);
    stored = stored.filter(s => s.workplaceName !== workplaceName);
    saveToStorage('isg_db_unit_settings', stored);
    logAction(admin, "BİRİM AYAR SİLME", `${workplaceName} biriminin özel ayarları silindi.`);
};

// --- DYNAMIC FILTERS ---
export const getUniqueWorkplaces = async (): Promise<string[]> => {
    const emps: Employee[] = loadFromStorage('isg_db_employees', []);
    const workplaces: string[] = emps
        .filter((e: Employee) => e.isActive && e.workplaceName)
        .map((e: Employee) => e.workplaceName.trim());
    return Array.from(new Set(workplaces)).sort();
};

// --- AUTH & USER SERVICES ---
let DEFAULT_USERS: User[] = [
  { id: 'u-admin', username: 'admin', password: 'admin123', role: 'ADMIN', name: 'Sistem Yöneticisi', status: 'ACTIVE', isAccessEnabled: true },
  { id: 'u-uzman', username: 'uzman', password: 'uzman123', role: 'SPECIALIST', name: 'İSG Uzmanı Ali', status: 'ACTIVE', isAccessEnabled: true },
  { id: 'u-hekim', username: 'hekim', password: 'hekim123', role: 'DOCTOR', name: 'Dr. Zeynep', status: 'ACTIVE', isAccessEnabled: true },
  { id: 'u-operator', username: 'operator', password: 'operator123', role: 'OPERATOR', name: 'Sistem Operatörü', status: 'ACTIVE', isAccessEnabled: true },
];

export const authenticateUser = async (username: string, pass: string): Promise<{ success: boolean; user?: User; message?: string }> => {
    const users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const user = users.find((u: User) => u.username === username);
    if (user && user.password === pass) {
        if (user.status !== 'ACTIVE') return { success: false, message: 'Hesabınız onay beklemektedir.' };
        logAction({ id: user.id, name: user.name }, "GİRİŞ", "Sisteme başarılı giriş yapıldı.");
        return { success: true, user };
    }
    return { success: false, message: 'Hatalı giriş.' };
};

export const registerUser = async (username: string, name: string, role: Role, details: any): Promise<{ success: boolean; message?: string }> => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    if (users.find((u: User) => u.username === username)) return { success: false, message: 'Kullanıcı adı alınmış.' };
    const newUser = { id: `u-${Date.now()}`, username, password: details.password || username + "123", name, role, status: 'PENDING', isAccessEnabled: false, ...details };
    users.push(newUser);
    saveToStorage('isg_db_users', users);
    logAction({ id: 'SYSTEM', name: 'Misafir' }, "KAYIT BAŞVURUSU", `${name} (${username}) yeni hesap başvurusu yaptı.`);
    return { success: true, message: 'Kayıt başvurusu alındı.' };
};

export const getAllUsers = async (role: Role): Promise<User[]> => loadFromStorage('isg_db_users', DEFAULT_USERS);
export const getPendingUsers = async (): Promise<User[]> => loadFromStorage('isg_db_users', DEFAULT_USERS).filter((u: User) => u.status === 'PENDING');

export const toggleUserAccess = async (userId: string, isEnabled: boolean, admin: any): Promise<void> => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const user = users.find((u: User) => u.id === userId);
    if (user) {
        user.isAccessEnabled = isEnabled;
        saveToStorage('isg_db_users', users);
        logAction(admin, "ERİŞİM YETKİSİ", `${user.name} kullanıcısının veri erişimi ${isEnabled ? 'AÇILDI' : 'KAPATILDI'}.`);
    }
};

export const approveUser = async (userId: string, admin: any): Promise<void> => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    let emps = loadFromStorage('isg_db_employees', []);
    const user = users.find((u: User) => u.id === userId);
    if (user) {
        user.status = 'ACTIVE';
        if (user.role === 'ADMIN' || user.role === 'OPERATOR') user.isAccessEnabled = true;
        if (user.tcNumber && !emps.find((e: Employee) => e.tcNumber === user.tcNumber)) {
            emps.push({ id: `emp-auto-${Date.now()}`, tcNumber: user.tcNumber, registrationNumber: user.registrationNumber || 'YENİ', fullName: user.name, birthDate: '', jobTitle: user.jobTitle || 'Atanmamış', workplaceName: user.workplaceName || 'Belirtilmemiş', phone: user.phone || '', hazardClass: user.hazardClass || 'TEHLIKELI', isActive: true });
            saveToStorage('isg_db_employees', emps);
        }
        saveToStorage('isg_db_users', users);
        logAction(admin, "KULLANICI ONAYI", `${user.name} kullanıcısının hesabı onaylandı.`);
    }
};

export const rejectUser = async (userId: string, admin: any) => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const user = users.find(u => u.id === userId);
    saveToStorage('isg_db_users', users.filter((u: User) => u.id !== userId));
    if (user) logAction(admin, "KULLANICI RED/SİL", `${user.name} kullanıcısının başvurusu reddedildi veya silindi.`);
};

export const deleteUser = async (userId: string, admin: any) => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const user = users.find(u => u.id === userId);
    saveToStorage('isg_db_users', users.filter((u: User) => u.id !== userId));
    if (user) logAction(admin, "KULLANICI SİLME", `${user.name} kullanıcısı sistemden kalıcı olarak silindi.`);
};

export const updateUserPassword = async (userId: string, newPass: string, admin: any) => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const u = users.find((x: User) => x.id === userId);
    if (u) { 
        u.password = newPass; 
        saveToStorage('isg_db_users', users);
        logAction(admin, "ŞİFRE GÜNCELLEME", `${u.name} kullanıcısının şifresi değiştirildi.`);
    }
};

export const updateUserRole = async (userId: string, newRole: Role, admin: any) => {
    let users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const u = users.find((x: User) => x.id === userId);
    if (u) { 
        u.role = newRole; 
        saveToStorage('isg_db_users', users);
        logAction(admin, "ROL GÜNCELLEME", `${u.name} kullanıcısının rolü ${newRole} olarak değiştirildi.`);
    }
};

// --- EMPLOYEE & RECORD SERVICES ---
export const getEmployees = async (all = false): Promise<Employee[]> => {
    const emps = loadFromStorage('isg_db_employees', []);
    return all ? emps : emps.filter((e: Employee) => e.isActive);
};

export const getEmployeesWithStatus = async (filters?: any, requestingUser?: User): Promise<(Employee & { risk: 'RED' | 'YELLOW' | 'GREEN', trainingDue: string, healthDue: string })[]> => {
    let emps = await getEmployees(true);
    
    if (requestingUser) {
        if (requestingUser.role === 'ADMIN' || requestingUser.role === 'OPERATOR') {
            // Tam erişim
        } 
        else if (requestingUser.role === 'SPECIALIST' || requestingUser.role === 'DOCTOR') {
            if (!requestingUser.isAccessEnabled) return []; 
            const assignments = loadFromStorage('isg_db_unit_assignments', []);
            const assignedWorkplaces = assignments
                .filter((a: UnitAssignment) => a.userId === requestingUser.id)
                .map((a: UnitAssignment) => a.workplaceName);
            emps = emps.filter(e => assignedWorkplaces.includes(e.workplaceName));
        }
        else if (requestingUser.role === 'PERSONNEL') {
            const unitSettings: UnitSetting[] = loadFromStorage('isg_db_unit_settings', []);
            const restrictedUnits = unitSettings.filter(s => s.isRestricted).map(s => s.workplaceName);
            emps = emps.filter(e => {
                if (e.workplaceName === requestingUser.workplaceName) return true;
                return !restrictedUnits.includes(e.workplaceName);
            });
        }
    }

    const records = loadFromStorage('isg_db_records', []).filter((r: ISGRecord) => r.status === 'APPROVED');
    const today = new Date().getTime();

    const mapped = emps.map(emp => {
        let maxRisk: 'RED' | 'YELLOW' | 'GREEN' = 'GREEN';
        let trainingDue = '---';
        let healthDue = '---';

        const trainingRecs = records.filter(r => r.employeeId === emp.id && r.type === 'ISG_TRAINING');
        const healthRecs = records.filter(r => r.employeeId === emp.id && r.type === 'HEALTH_CHECK');

        const getLatestDue = (recs: ISGRecord[]) => {
            if (recs.length === 0) return null;
            return [...recs].sort((a, b) => (parseTRDate(b.nextDueDate)?.getTime() || 0) - (parseTRDate(a.nextDueDate)?.getTime() || 0))[0];
        };

        const tLatest = getLatestDue(trainingRecs);
        const hLatest = getLatestDue(healthRecs);

        if (tLatest) trainingDue = tLatest.nextDueDate;
        if (hLatest) healthDue = hLatest.nextDueDate;

        // Risk hesaplama
        for (const latest of [tLatest, hLatest]) {
            if (!latest) {
                maxRisk = 'RED';
            } else {
                const nextDate = parseTRDate(latest.nextDueDate)?.getTime() || 0;
                const diffDays = Math.ceil((nextDate - today) / (1000 * 60 * 60 * 24));
                if (diffDays <= 0) { 
                    maxRisk = 'RED'; 
                    break; 
                } else if (diffDays <= 60 && maxRisk !== 'RED') { 
                    maxRisk = 'YELLOW'; 
                }
            }
        }

        return { ...emp, risk: maxRisk, trainingDue, healthDue };
    });

    if (filters) {
        let res = mapped.filter(e => e.isActive);
        if (filters.workplace) res = res.filter(e => e.workplaceName === filters.workplace);
        if (filters.hazardClass) res = res.filter(e => e.hazardClass === filters.hazardClass);
        if (filters.status) res = res.filter(e => e.risk === filters.status);
        return res;
    }
    return mapped;
};

export const getEmployeeById = async (id: string, requestingUser?: User) => {
    const emp = (await getEmployees(true)).find(e => e.id === id);
    if (!emp || !requestingUser) return emp;

    if (requestingUser.role === 'SPECIALIST' || requestingUser.role === 'DOCTOR') {
        if (!requestingUser.isAccessEnabled) return undefined;
        const assignments = loadFromStorage('isg_db_unit_assignments', []);
        const isAssigned = assignments.some((a: UnitAssignment) => a.userId === requestingUser.id && a.workplaceName === emp.workplaceName);
        if (!isAssigned) return undefined;
    }
    
    return emp;
};

export const getEmployeeByTc = async (tc: string) => (await getEmployees(true)).find(e => e.tcNumber === tc);

export const createEmployee = async (data: any, admin: any) => {
    let emps = loadFromStorage('isg_db_employees', []);
    if (emps.find((e: Employee) => e.tcNumber === data.tcNumber)) throw new Error("Mükerrer TC No.");
    const newEmp = { id: `emp-${Date.now()}`, isActive: true, ...data, birthDate: normalizeDate(data.birthDate) };
    emps.push(newEmp);
    saveToStorage('isg_db_employees', emps);
    logAction(admin, "PERSONEL EKLEME", `${newEmp.fullName} (${newEmp.tcNumber}) personeli eklendi.`);
    return newEmp;
};

export const deleteEmployee = async (id: string, admin: any) => {
    let emps = loadFromStorage('isg_db_employees', []);
    const emp = emps.find(e => e.id === id);
    saveToStorage('isg_db_employees', emps.filter((e: Employee) => e.id !== id));
    if (emp) logAction(admin, "PERSONEL SİLME", `${emp.fullName} personeli kalıcı olarak silindi.`);
};

export const getAllRecords = async () => loadFromStorage('isg_db_records', []);
export const getRecords = async (empId: string, status?: string) => {
    let recs = await getAllRecords();
    recs = recs.filter((r: ISGRecord) => r.employeeId === empId);
    if (status) recs = recs.filter((r: ISGRecord) => r.status === status);
    return recs;
};

export const createRecord = async (data: any, hazardClass: HazardClass, user: any) => {
    const trDate = normalizeDate(data.date);
    if (!trDate) throw new Error("Geçersiz tarih.");
    const nextDueDate = calculateNextDueDate(trDate, data.type, hazardClass);
    const newRec = { id: `rec-${Date.now()}`, employeeId: data.employeeId, type: data.type, date: trDate, nextDueDate, performer: data.performer, status: 'PENDING', createdBy: user.id, createdAt: new Date().toISOString() };
    let all = await getAllRecords();
    all.push(newRec);
    saveToStorage('isg_db_records', all);
    logAction(user, "YENİ KAYIT GİRİŞİ", `${RECORD_CONFIGS[data.type].label} girişi yapıldı, onay bekliyor.`);
    return newRec;
};

export const approveRecord = async (id: string, admin: any) => {
    let all = await getAllRecords();
    const rec = all.find((r: ISGRecord) => r.id === id);
    if (rec) { 
        rec.status = 'APPROVED'; 
        saveToStorage('isg_db_records', all); 
        logAction(admin, "KAYIT ONAYI", `Bir İSG kaydı onaylandı.`);
    }
};

export const rejectRecord = async (id: string, admin: any) => {
    let all = await getAllRecords();
    saveToStorage('isg_db_records', all.filter((r: ISGRecord) => r.id !== id));
    logAction(admin, "KAYIT RED/SİL", `Bir İSG kaydı reddedildi veya silindi.`);
};

export const deleteRecord = async (id: string, admin: any) => {
    let all = await getAllRecords();
    saveToStorage('isg_db_records', all.filter((r: ISGRecord) => r.id !== id));
    logAction(admin, "KAYIT SİLME", `Bir İSG kaydı kalıcı olarak silindi.`);
};

export const bulkApproveRecords = async (ids: string[], admin: any) => {
    let all = await getAllRecords();
    all.forEach((r: ISGRecord) => { if (ids.includes(r.id)) r.status = 'APPROVED'; });
    saveToStorage('isg_db_records', all);
    logAction(admin, "TOPLU KAYIT ONAYI", `${ids.length} adet İSG kaydı toplu olarak onaylandı.`);
};

// --- FORMS & DOCUMENTS ---
export const getSharedForms = async (): Promise<SharedForm[]> => loadFromStorage('isg_db_shared_forms', []);
export const uploadSharedForm = async (form: any, user: any) => {
    let all = await getSharedForms();
    const newForm = { ...form, id: `form-${Date.now()}`, uploadDate: new Date().toISOString() };
    all.push(newForm);
    saveToStorage('isg_db_shared_forms', all);
    logAction(user, "FORM YÜKLEME", `${newForm.name} kurumsal formu yüklendi.`);
    return newForm;
};

export const deleteSharedForm = async (id: string, user: any) => {
    let all = await getSharedForms();
    const form = all.find(f => f.id === id);
    saveToStorage('isg_db_shared_forms', all.filter((f: SharedForm) => f.id !== id));
    if (form) logAction(user, "FORM SİLME", `${form.name} kurumsal formu silindi.`);
};

export const getEmployeeDocuments = async (empId: string) => loadFromStorage('isg_db_documents', []).filter((d: EmployeeDocument) => d.employeeId === empId);

export const uploadEmployeeDocument = async (doc: any, user: any) => {
    let all = loadFromStorage('isg_db_documents', []);
    const newDoc = { ...doc, id: `doc-${Date.now()}`, uploadDate: new Date().toISOString() };
    all.push(newDoc);
    saveToStorage('isg_db_documents', all);
    logAction(user, "DOKÜMAN YÜKLEME", `Personel için ${newDoc.type} türünde belge yüklendi.`);
    return newDoc;
};

export const deleteEmployeeDocument = async (id: string, user: any) => {
    let all = loadFromStorage('isg_db_documents', []);
    const doc = all.find(d => d.id === id);
    saveToStorage('isg_db_documents', all.filter((d: EmployeeDocument) => d.id !== id));
    if (doc) logAction(user, "DOKÜMAN SİLME", `Personel belgesi silindi.`);
};

// --- STATS ---
export const getDashboardStats = async (filters?: any, user?: User): Promise<DashboardStats> => {
    const mapped = await getEmployeesWithStatus(filters, user);
    const users = loadFromStorage('isg_db_users', DEFAULT_USERS);
    const recs = loadFromStorage('isg_db_records', []);

    return {
        totalPersonnel: mapped.length,
        pendingApprovals: recs.filter((r: ISGRecord) => r.status === 'PENDING').length,
        pendingUserApprovals: users.filter((u: User) => u.status === 'PENDING').length,
        riskRed: mapped.filter(i => i.risk === 'RED').length,
        riskYellow: mapped.filter(i => i.risk === 'YELLOW').length,
        riskGreen: mapped.filter(i => i.risk === 'GREEN').length
    };
};
export const getAuditLogs = async () => loadFromStorage('isg_db_logs', []);

// --- IMPORT / EXPORT ---
export const importFromExcelMock = async (buffer: ArrayBuffer, admin: any) => {
    let content = "";
    try { content = new TextDecoder('utf-8', { fatal: true }).decode(buffer); } catch { content = new TextDecoder('windows-1254').decode(buffer); }
    const rows = content.replace(/^\uFEFF/, '').trim().split(/\r?\n/).filter(r => r.trim());
    const del = rows[0].includes(';') ? ';' : ',';
    let emps = loadFromStorage('isg_db_employees', []);
    let recs = loadFromStorage('isg_db_records', []);
    let pCount = 0, rCount = 0;
    for (let i = 1; i < rows.length; i++) {
        const cols = rows[i].split(del).map(c => c.replace(/^"|"$/g, '').trim());
        if (cols.length < 2) continue;
        const [fullName, tc, birth, job, wp, phone, hazardRaw, isgRaw, healthRaw, regNo] = cols;
        if (!tc || !isValidTC(tc)) continue;
        let hazardClass: HazardClass = 'TEHLIKELI';
        if (hazardRaw?.toLowerCase().includes('az')) hazardClass = 'AZ_TEHLIKELI';
        else if (hazardRaw?.toLowerCase().includes('çok')) hazardClass = 'COK_TEHLIKELI';
        let emp = emps.find((e: Employee) => e.tcNumber === tc);
        if (!emp) {
            emp = { id: `emp-x-${Date.now()}-${i}`, tcNumber: tc, registrationNumber: regNo || 'YENİ', fullName: fullName || 'İsimsiz', jobTitle: job || '---', workplaceName: wp || '---', phone: phone || '', birthDate: normalizeDate(birth), hazardClass, isActive: true };
            emps.push(emp); pCount++;
        }
        const addR = (raw: string, type: RecordTypeKey) => {
            const date = normalizeDate(raw); if (!date) return;
            recs.push({ id: `rec-x-${Date.now()}-${Math.random()}`, employeeId: emp!.id, type, date, nextDueDate: calculateNextDueDate(date, type, emp!.hazardClass), performer: 'Excel', status: 'APPROVED', createdBy: admin.id, createdAt: new Date().toISOString() });
            rCount++;
        };
        addR(isgRaw, 'ISG_TRAINING'); addR(healthRaw, 'HEALTH_CHECK');
    }
    saveToStorage('isg_db_employees', emps); saveToStorage('isg_db_records', recs);
    logAction(admin, "TOPLU VERİ AKTARIMI", `${pCount} personel ve ${rCount} kayıt Excel'den aktarıldı.`);
    return { personnel: pCount, records: rCount, skipped: 0 };
};

export const exportToExcel = (data: any[], filename: string) => {
    if (!data.length) return;
    const keys = Object.keys(data[0]);
    const csv = "\uFEFF" + keys.join(';') + '\n' + data.map(r => keys.map(k => `"${r[k]}"`).join(';')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${filename}.csv`; a.click();
};

/**
 * Downloads a predefined CSV template for bulk employee data import.
 */
export const downloadExcelTemplate = () => {
    const data = [{
        [EXCEL_HEADERS[0]]: "Ahmet Örnek",
        [EXCEL_HEADERS[1]]: "12345678910",
        [EXCEL_HEADERS[2]]: "01.01.1990",
        [EXCEL_HEADERS[3]]: "Operatör",
        [EXCEL_HEADERS[4]]: "Merkez Atölye",
        [EXCEL_HEADERS[5]]: "05554443322",
        [EXCEL_HEADERS[6]]: "Çok Tehlikeli",
        [EXCEL_HEADERS[7]]: "15.01.2024",
        [EXCEL_HEADERS[8]]: "10.01.2024",
        [EXCEL_HEADERS[9]]: "S-2024-001" // Sicil No örneği
    }];
    exportToExcel(data, "ISG_Veri_Aktarim_Sablonu");
};
