import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Role, User, HazardClass } from '../types';
import { authenticateUser, registerUser } from '../services/mockDataService';

interface RegisterDetails {
  tcNumber: string;
  workplaceName: string;
  jobTitle: string;
  hazardClass: HazardClass;
  phone: string;
}

interface AuthContextType {
  currentUser: User | null;
  login: (username: string, pass: string) => Promise<{ success: boolean; message?: string }>;
  register: (username: string, pass: string, name: string, role: Role, details?: RegisterDetails) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  role: Role;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('isg_user_v2');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (username: string, pass: string): Promise<{ success: boolean; message?: string }> => {
    const result = await authenticateUser(username, pass);
    
    if (result.success && result.user) {
      setCurrentUser(result.user);
      localStorage.setItem('isg_user_v2', JSON.stringify(result.user));
      return { success: true };
    }
    return { success: false, message: result.message || 'Giriş hatası.' };
  };

  const register = async (username: string, pass: string, name: string, role: Role, details?: RegisterDetails): Promise<{ success: boolean; message?: string }> => {
    // Note: mockDataService handles persistence
    // We pass defaults if details undefined, though form requires them
    const safeDetails = details || { tcNumber: '', workplaceName: '', jobTitle: '', hazardClass: 'TEHLIKELI', phone: '' };
    return await registerUser(username, name, role, safeDetails);
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('isg_user_v2');
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      login, 
      register,
      logout, 
      role: currentUser?.role || 'VIEWER',
      isAuthenticated: !!currentUser 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};